#!/usr/bin/env node
/**
 * QA smoke — parser, templates, placeholders (no browser).
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import vm from 'vm';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, '..');

const PLACEHOLDER_PATTERNS = [
  /Candidate\s*Name/i,
  /email@example\.com/i,
  /\bCompany\b(?!\s*·)/,
  /Professional\s+profile\s+fake/i,
  /Jane\s+Doe/i,
  /John\s+Doe/i,
  /professionally\s+positioned/i,
  /\[add\s+metric\]/i,
];

function loadBrowserParser() {
  const parserCode = fs.readFileSync(path.join(root, 'public/lib/hirely-cv-parser.js'), 'utf8');
  const tplCode = fs.readFileSync(path.join(root, 'public/lib/hirely-cv-templates.js'), 'utf8');
  const sandbox = {
    console,
    escapeHtml: (s) =>
      String(s || '').replace(/[&<>"']/g, (m) =>
        ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[m]
      ),
    cvSection: (id, title, html) => {
      const body = (html || '').replace(/<[^>]+>/g, '').trim();
      if (!body) return '';
      if (sandbox.HirelyCvParser?.isPlaceholder?.(body)) return '';
      return `<section data-section="${id}">${html}</section>`;
    },
    photoData: '',
  };
  sandbox.window = sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(parserCode, sandbox);
  vm.runInContext(tplCode, sandbox);
  return sandbox;
}

function sampleText() {
  return `Yohann Azancot
Graphic Designer & Illustrator
yoaz@hotmail.fr · +33 6 49 43 48 39

Summary
Creative professional specializing in illustration, graphic design and visual storytelling.

Clients
Nike, Louis Vuitton, Marvel, Cadillac, Fortune, Converse, Pantone, Adobe, Arte, McCann

Work Experience
2011–Present — Freelance Illustrator / Graphic Designer
Independent / Freelance
- Created high-impact illustration and graphic design work.
- Collaborated with recognized brands including Nike, Louis Vuitton, Marvel.

Education
LISAA — Web & Motion Design
Créapole — Visual Communication / Product Design

Skills
Illustration, Graphic Design, Visual Identity

Tools
Photoshop, Illustrator, InDesign

Languages
French — native
English — fluent`;
}

const TEMPLATE_IDS = ['ats', 'swiss', 'executive', 'editorial', 'portfolio', 'luxury', 'sidebar', 'art'];

function stripHtml(html) {
  return html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function run() {
  const ctx = loadBrowserParser();
  const { HirelyCvParser, HirelyCvTemplates } = ctx;
  const text = sampleText();
  const cv = HirelyCvParser.parseCvText(HirelyCvParser.cleanCvText(text), 'Senior Graphic Designer');
  const sanitized = HirelyCvParser.sanitizePremiumCV(cv);

  const results = { pass: [], fail: [], warn: [] };

  if (!sanitized.name || /candidate/i.test(sanitized.name)) {
    results.fail.push(`parse: name="${sanitized.name}"`);
  } else if (!sanitized.name.includes('Yohann')) {
    results.fail.push(`parse: unexpected name="${sanitized.name}"`);
  } else {
    results.pass.push(`parse: name="${sanitized.name}"`);
  }

  if (!sanitized.contact?.includes('yoaz@hotmail')) {
    results.fail.push(`parse: contact missing real email (${sanitized.contact})`);
  } else {
    results.pass.push('parse: real contact');
  }

  if (!(sanitized.experience?.length > 0)) {
    results.fail.push('parse: no experience');
  } else {
    results.pass.push(`parse: ${sanitized.experience.length} experience entries`);
  }

  for (const id of TEMPLATE_IDS) {
    const html = HirelyCvTemplates.build(sanitized, id);
    const plain = stripHtml(html);
    if (plain.length < 80) {
      results.fail.push(`template ${id}: too little content (${plain.length} chars)`);
      continue;
    }
    const bad = PLACEHOLDER_PATTERNS.filter((re) => re.test(plain));
    if (bad.length) {
      results.fail.push(`template ${id}: placeholders ${bad.map((r) => r.source).join(', ')}`);
    } else if (!plain.includes('Yohann') && !plain.includes('yoaz')) {
      results.fail.push(`template ${id}: missing real identity in output`);
    } else {
      results.pass.push(`template ${id}: ${plain.length} chars, no placeholders`);
    }
  }

  const fb = HirelyCvParser.buildFallbackFromCv(text, 'Senior Graphic Designer');
  const fbPlain = JSON.stringify(fb.premiumCV);
  const fbBad = PLACEHOLDER_PATTERNS.filter((re) => re.test(fbPlain));
  if (fbBad.length) results.fail.push(`fallback JSON: ${fbBad.map((r) => r.source).join(', ')}`);
  else results.pass.push('fallback: no placeholders in premiumCV');

  const indexHtml = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  const checks = [
    ['cvWorkspaceSection', /id="result"[^>]*class="[^"]*cvWorkspaceSection/],
    ['templatePicker', /id="templatePicker"/],
    ['layout-stacked', /layout-stacked/],
    ['html2pdf', /html2pdf/],
    ['isPro test=yoaz', /p\.get\('test'\)==='yoaz'/],
    ['hirely-pricing.css', /hirely-pricing\.css/],
    ['hirely-template-picker.css', /hirely-template-picker\.css/],
  ];
  for (const [name, re] of checks) {
    if (re.test(indexHtml)) results.pass.push(`html: ${name}`);
    else results.fail.push(`html: missing ${name}`);
  }

  const mobileCss =
    (fs.existsSync(path.join(root, 'public/css/hirely-cv-workspace.css')) &&
      fs.readFileSync(path.join(root, 'public/css/hirely-cv-workspace.css'), 'utf8')) ||
    '';
  if (/max-width:\s*920px/.test(mobileCss) || /@media\s*\(max-width:\s*900px\)/.test(indexHtml)) {
    results.pass.push('css: mobile breakpoints present');
  } else {
    results.warn.push('css: mobile breakpoints not verified in workspace');
  }

  console.log('\n=== QA SMOKE (automated) ===\n');
  console.log('PASS:', results.pass.length);
  results.pass.forEach((p) => console.log('  ✓', p));
  if (results.warn.length) {
    console.log('\nWARN:', results.warn.length);
    results.warn.forEach((w) => console.log('  !', w));
  }
  if (results.fail.length) {
    console.log('\nFAIL:', results.fail.length);
    results.fail.forEach((f) => console.log('  ✗', f));
    process.exit(1);
  }
  console.log('\nAll automated checks passed.\n');
}

run();
