# Hirely — Final Cursor Stable UI

Stable Cursor-ready version.

## Run
```bash
npm install
npx vercel dev
```

Open: http://localhost:3000/?test=yoaz

## Important
- Use `npx vercel dev`, not plain Vite, when testing `/api/analyze`.
- Add `.env.local` with `GEMINI_API_KEY=...` for real AI.
- If Gemini is missing, Hirely still generates a safe professional draft locally.

## Preserved product DNA
- Apple/Linear minimal design
- upload → clean → score → generate → edit → PDF
- Pro CV / Audit / LinkedIn / Letter
- editable CV templates
- Stripe paywall
