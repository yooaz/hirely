# Canonical Hirely source (Stable V3 UI)

**This workspace** is the Hirely preview source:

`/Users/yohannazancot/YOAZ_STUDIO_OS/hirely_FINAL_CURSOR_STABLE_UI`

```bash
cd ~/YOAZ_STUDIO_OS/hirely_FINAL_CURSOR_STABLE_UI
npm run dev
```

Open **http://127.0.0.1:3039/** — not port 5173/5174 (those may be STUDIO THE BRAIN).

Local Pro preview: `?test=yoaz` or `?pro=true` on localhost.

API (optional): copy `api/` from `INBOX_TO_SORT/hirely-os` and run `npx vercel dev --listen 3099` in that folder.
