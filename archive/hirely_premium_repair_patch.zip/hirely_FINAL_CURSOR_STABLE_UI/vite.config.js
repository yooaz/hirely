import { defineConfig } from 'vite';

/** Hirely only — do not share 5173/5174 with other YOAZ apps */
export default defineConfig({
  root: '.',
  server: {
    port: 3039,
    strictPort: true,
    host: '127.0.0.1',
    open: '/',
  },
  preview: {
    port: 3039,
    strictPort: true,
  },
});
