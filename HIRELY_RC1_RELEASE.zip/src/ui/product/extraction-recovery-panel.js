/**
 * Extraction Recovery UI — Detected Issues · Missing Sections · Low Confidence Fields
 */
(function (global) {
  const FIELD_ACTION_MAP = {
    name: 'name',
    title: 'title',
    email: 'email',
    phone: 'phone',
    experience: 'experience',
    education: 'education',
    skills: 'skills',
    tools: 'skills',
    languages: 'skills',
  };

  function esc(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function renderList(items, emptyLabel) {
    if (!items.length) {
      return `<p class="extractionRecoveryEmpty">${esc(emptyLabel)}</p>`;
    }
    return `<ul class="extractionRecoveryList">${items
      .map((it) => {
        const action = FIELD_ACTION_MAP[it.field] || it.field || 'edit';
        const btn =
          it.action !== 'ignore'
            ? `<button type="button" class="btn small ghost extractionRecoveryFix" data-recovery-action="${esc(action)}" data-recovery-field="${esc(it.field || '')}">Fix</button>`
            : '';
        const meta =
          it.confidence != null && it.confidence > 0
            ? `<span class="extractionRecoveryMeta">${it.confidence}%</span>`
            : '';
        const val = it.value || it.sourceText;
        const sub = val ? `<span class="extractionRecoverySub">${esc(String(val).slice(0, 120))}</span>` : '';
        return `<li class="extractionRecoveryItem"><div class="extractionRecoveryItemMain"><span class="extractionRecoveryMsg">${esc(it.message || it.label || it.field)}</span>${meta}${sub}</div>${btn}</li>`;
      })
      .join('')}</ul>`;
  }

  function renderMissingSections(sections) {
    if (!sections.length) {
      return '<p class="extractionRecoveryEmpty">All required sections detected.</p>';
    }
    return `<ul class="extractionRecoveryList">${sections
      .map((s) => {
        const action = FIELD_ACTION_MAP[s.id] || s.id;
        return `<li class="extractionRecoveryItem extractionRecoveryItem--miss"><div class="extractionRecoveryItemMain"><span class="extractionRecoveryMsg">${esc(s.label || s.id)}</span><span class="extractionRecoverySub">Section missing or incomplete</span></div><button type="button" class="btn small ghost extractionRecoveryFix" data-recovery-action="${esc(action)}">${esc('Add')}</button></li>`;
      })
      .join('')}</ul>`;
  }

  function renderLowConfidence(fields) {
    if (!fields.length) {
      return '<p class="extractionRecoveryEmpty">No low-confidence fields.</p>';
    }
    return renderList(
      fields.map((f) => ({
        field: f.field,
        message: `${f.field} — verify (${f.confidence}%)`,
        value: f.value,
        confidence: f.confidence,
        action: 'edit',
      })),
      'No low-confidence fields.'
    );
  }

  function renderExtractionRecoveryPanel(report, opts = {}) {
    const host = opts.host || global.document?.getElementById('extractionRecoveryPanel');
    if (!host) return;

    const show = !!(report && report.showRecovery);
    host.classList.toggle('hidden', !show);
    if (!show) {
      host.innerHTML = '';
      return;
    }

    const t = opts.t || ((k) => k);
    const safe = report.outputSafe && !report.blockRender;

    host.innerHTML = `
      <div class="extractionRecoveryHead">
        <span class="kicker">${esc(t('extractionRecoveryKicker') || 'Extraction review')}</span>
        <h3>${esc(t('extractionRecoveryTitle') || 'Detected Issues')}</h3>
        <p class="extractionRecoveryLead">${esc(
          safe
            ? t('extractionRecoveryLeadOk') || 'Review suggested items before export.'
            : t('extractionRecoveryLeadBlock') ||
                'Some fields need correction — we will not show a broken CV until you fix them.'
        )}</p>
        ${
          !safe
            ? `<p class="extractionRecoveryBanner" role="status">${esc(
                t('extractionRecoveryBlocked') || 'CV preview paused until critical issues are resolved.'
              )}</p>`
            : ''
        }
      </div>
      <section class="extractionRecoveryBlock" aria-labelledby="extractionRecoveryIssuesTitle">
        <h4 id="extractionRecoveryIssuesTitle">${esc(t('extractionRecoveryIssues') || 'Detected Issues')}</h4>
        ${renderList(report.detectedIssues || [], t('extractionRecoveryIssuesEmpty') || 'No open issues.')}
      </section>
      <section class="extractionRecoveryBlock" aria-labelledby="extractionRecoveryMissingTitle">
        <h4 id="extractionRecoveryMissingTitle">${esc(t('extractionRecoveryMissing') || 'Missing Sections')}</h4>
        ${renderMissingSections(report.missingSections || [])}
      </section>
      <section class="extractionRecoveryBlock" aria-labelledby="extractionRecoveryLowTitle">
        <h4 id="extractionRecoveryLowTitle">${esc(t('extractionRecoveryLowConf') || 'Low Confidence Fields')}</h4>
        ${renderLowConfidence(report.lowConfidenceFields || [])}
      </section>
    `;

    if (!host._recoveryBound) {
      host._recoveryBound = true;
      host.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-recovery-action]');
        if (!btn) return;
        const action = btn.dataset.recoveryAction;
        if (typeof opts.onFix === 'function') opts.onFix(action, btn.dataset.recoveryField || '');
      });
    }
  }

  global.HirelyExtractionRecoveryPanel = {
    renderExtractionRecoveryPanel,
    FIELD_ACTION_MAP,
  };
})(typeof window !== 'undefined' ? window : globalThis);
