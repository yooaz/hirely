/**
 * HIRELY Template Library V3 — 10 differentiated recruiter-grade templates.
 * Each family differs in grid, hierarchy, typography, spacing, and structure.
 */

export const TEMPLATE_LIBRARY_V3_VERSION = 'TEMPLATE_LIBRARY_V3';

/** Production gallery — exactly 10 premium templates (role categories). */
export const TEMPLATE_FAMILY_V3_IDS = Object.freeze([
  'executive-board',
  'consulting-elite',
  'startup-founder',
  'apple-style',
  'creative-director',
  'senior-engineer',
  'google-style',
  'luxury-editorial',
  'minimal-ats',
  'premium-ats',
]);

export const TEMPLATE_FAMILY_V3_NAMES = Object.freeze({
  'executive-board': 'Executive',
  'consulting-elite': 'Consulting',
  'startup-founder': 'Startup',
  'apple-style': 'Designer',
  'creative-director': 'Creative Director',
  'senior-engineer': 'Engineer',
  'google-style': 'Product Manager',
  'luxury-editorial': 'Marketing',
  'minimal-ats': 'Minimal ATS',
  'premium-ats': 'Premium ATS',
});

/** Role category for gallery grouping. */
export const TEMPLATE_FAMILY_V3_CATEGORIES = Object.freeze({
  'executive-board': 'Executive',
  'consulting-elite': 'Consulting',
  'startup-founder': 'Startup',
  'apple-style': 'Designer',
  'creative-director': 'Creative Director',
  'senior-engineer': 'Engineer',
  'google-style': 'Product Manager',
  'luxury-editorial': 'Marketing',
  'minimal-ats': 'Minimal ATS',
  'premium-ats': 'Premium ATS',
});

/** V2 / legacy ids → V3 canonical id. */
export const TEMPLATE_FAMILY_V3_ALIASES = Object.freeze({
  'mckinsey-consulting': 'consulting-elite',
  consulting: 'consulting-elite',
  '02-consulting': 'consulting-elite',
  strategy: 'consulting-elite',
  'agency-designer': 'consulting-elite',
  'apple-minimal': 'apple-style',
  minimal: 'apple-style',
  '07-minimal': 'apple-style',
  apple: 'apple-style',
  'visual-timeline': 'apple-style',
  timeline: 'apple-style',
  'tech-engineer': 'google-style',
  tech: 'google-style',
  '05-tech': 'google-style',
  'tech-structured': 'google-style',
  'modern-two-column': 'google-style',
  'creative-director-portfolio': 'creative-director',
  creative: 'creative-director',
  '03-creative': 'creative-director',
  'art-director': 'creative-director',
  'art-director-portfolio': 'creative-director',
  'kinfolk-editorial': 'luxury-editorial',
  'editorial-magazine': 'luxury-editorial',
  editorial: 'luxury-editorial',
  'luxury-executive': 'executive-board',
  '01-executive': 'executive-board',
  executive: 'executive-board',
  'executive-luxury': 'executive-board',
  'ats-executive': 'executive-board',
  'ats-recruiter': 'premium-ats',
  '08-premium-ats': 'premium-ats',
  'premium-ats': 'premium-ats',
  'ats-elite': 'premium-ats',
  'ats-clean': 'minimal-ats',
  academic: 'premium-ats',
  'academic-cv': 'premium-ats',
  research: 'premium-ats',
  designer: 'apple-style',
  marketing: 'luxury-editorial',
  engineer: 'senior-engineer',
  'product-manager': 'google-style',
  'classic-corporate': 'executive-board',
  '06-corporate': 'executive-board',
  corporate: 'executive-board',
  'swiss-editorial': 'luxury-editorial',
  startup: 'startup-founder',
  '04-startup': 'startup-founder',
  'startup-builder': 'startup-founder',
  founder: 'startup-founder',
  'senior-engineer': 'senior-engineer',
  'staff-engineer': 'senior-engineer',
  'principal-engineer': 'senior-engineer',
  designer: 'apple-style',
  marketing: 'luxury-editorial',
  engineer: 'senior-engineer',
  'product-manager': 'google-style',
});

export const TEMPLATE_FAMILY_V3_CSS = 'cv-templates-v3-families.css';

export const TEMPLATE_FAMILY_V3_ARCHITECTURE = Object.freeze({
  'consulting-elite': {
    grid: '3/9 asymmetric split · KPI strip · impact matrix footer',
    hierarchy: 'Engagement thesis → Case experience → Credentials rail',
    typography: 'Cormorant Garamond display · IBM Plex Sans body · navy ink',
    spacing: '28px section rhythm · 14px matrix cells · 32px masthead',
    emphasis: 'Quantified outcomes · MBB case credibility',
    layoutFamily: 'consulting-split-v3',
    sectionOrder: ['summary', 'experience', 'education', 'skills', 'languages'],
  },
  'apple-style': {
    grid: 'Centered monument · left timeline spine · 56px margins',
    hierarchy: 'Identity monument → Career spine → Skills whisper',
    typography: 'SF Pro–style Inter · 36pt name · -0.04em tracking · hairline rules',
    spacing: 'Apple keynote · 44px between sections · 18px spine nodes',
    emphasis: 'Designer portfolio clarity · visual discipline · document-first',
    layoutFamily: 'designer-monument-v3',
    sectionOrder: ['experience', 'education', 'skills', 'tools', 'languages'],
  },
  'google-style': {
    grid: '4-color accent bar · 26/74 skills rail · systems column',
    hierarchy: 'Stack rail → Shipped systems → Projects',
    typography: 'Product Sans headings · multi-hue bar · roadmap rhythm',
    spacing: 'Material 12px tight body · 20px rail gaps',
    emphasis: 'Product leadership · roadmap clarity · stakeholder scan',
    layoutFamily: 'product-manager-rail-v3',
    sectionOrder: ['skills', 'tools', 'experience', 'projects', 'education'],
  },
  'startup-founder': {
    grid: 'Venture hero · traction metrics · 24/76 operator split',
    hierarchy: 'Founder thesis → Traction → Roles & impact',
    typography: 'Inter 800 display · Linear purple · mono metrics',
    spacing: 'Operator 14px body · 28px hero · 18px rail',
    emphasis: 'Product velocity · venture narrative',
    layoutFamily: 'founder-split-v3',
    sectionOrder: ['summary', 'experience', 'clients', 'projects', 'education', 'skills'],
  },
  'creative-director': {
    grid: 'Hero band · 3-col client proof · asymmetric case stack',
    hierarchy: 'Identity hero → Clients → Projects → Career',
    typography: 'Fraunces display · DM Sans UI · warm coral accent',
    spacing: 'Portfolio 36px hero · 16px client grid · 24px cases',
    emphasis: 'Brand proof · creative leadership · visual hierarchy',
    layoutFamily: 'portfolio-hero-v3',
    sectionOrder: ['clients', 'projects', 'experience', 'skills', 'education'],
  },
  'senior-engineer': {
    grid: '20/80 mono rail · dense experience cards · stack blocks',
    hierarchy: 'Engineering identity → Stack rail → Systems shipped',
    typography: 'JetBrains Mono accents · Inter body · GitHub-style density',
    spacing: 'Engineering 11px tight · 8px card gaps · compact rail',
    emphasis: 'Technical depth · systems at scale · staff-level scope',
    layoutFamily: 'engineer-dense-v3',
    sectionOrder: ['skills', 'tools', 'experience', 'projects', 'education'],
  },
  'executive-board': {
    grid: 'Centered board masthead · single narrative · gold rule',
    hierarchy: 'Board identity → Executive summary → Leadership',
    typography: 'Source Serif 4 · IBM Plex Sans · gold hairline · slate ink',
    spacing: 'Boardroom 40px margins · 32px section gaps',
    emphasis: 'C-suite gravitas · governance · achievement ribbon',
    layoutFamily: 'executive-centered-v3',
    sectionOrder: ['summary', 'experience', 'education', 'skills', 'languages'],
  },
  'minimal-ats': {
    grid: 'Single column · 68ch · utility contact band · date grid',
    hierarchy: 'Experience → Education → Skills (recruiter scan)',
    typography: 'Inter · 8pt labels · tabular nums · pure black/white',
    spacing: 'Ultra-dense 8px rhythm · zero ornament',
    emphasis: 'Parse density · recruiter scan · export fidelity',
    layoutFamily: 'dense-ats-v3',
    sectionOrder: ['experience', 'education', 'skills', 'tools', 'languages', 'summary'],
  },
  'premium-ats': {
    grid: 'Indigo recruiter band · dual-column experience grid · parse ribbon',
    hierarchy: 'Identity band → Dense experience table → Credential stack',
    typography: 'Inter · tabular nums · indigo accent · recruiter labels',
    spacing: 'Premium ATS 7px rhythm · score-band header · zero clip',
    emphasis: 'Enterprise ATS parse · premium recruiter scan · export fidelity',
    layoutFamily: 'premium-ats-v3',
    sectionOrder: ['experience', 'education', 'skills', 'tools', 'languages', 'summary'],
  },
  'luxury-editorial': {
    grid: 'Magazine cover · 22/48/30 three-column spread',
    hierarchy: 'Cover identity → Feature column → Sidebar credentials',
    typography: 'Playfair Display · Lora body · tracked small caps',
    spacing: 'Editorial 24px cover · 14px column gutters · float rhythm',
    emphasis: 'Marketing narrative · campaign proof · brand storytelling',
    layoutFamily: 'marketing-spread-v3',
    sectionOrder: ['summary', 'experience', 'clients', 'education', 'skills'],
  },
});

/**
 * @param {string} templateId
 */
export function resolveTemplateFamilyV3Id(templateId) {
  const id = String(templateId || '').trim();
  if (TEMPLATE_FAMILY_V3_IDS.includes(id)) return id;
  return TEMPLATE_FAMILY_V3_ALIASES[id] || id;
}

/**
 * @param {string} templateId
 */
export function templateFamilyV3DisplayName(templateId) {
  const id = resolveTemplateFamilyV3Id(templateId);
  return TEMPLATE_FAMILY_V3_NAMES[id] || id;
}
