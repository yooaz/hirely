/**
 * Premium Template Gallery — use-case catalog for keynote-style template picker.
 * Render-only metadata; no parser or import logic.
 */

/** @typedef {'all'|'ats'|'creative'|'executive'|'portfolio'|'tech'|'consulting'} GalleryUseCase */

export const PREMIUM_GALLERY_USE_CASES = Object.freeze([
  { id: 'all', label: 'All', labelFr: 'Tous' },
  { id: 'ats', label: 'ATS', labelFr: 'ATS' },
  { id: 'creative', label: 'Creative', labelFr: 'Créatif' },
  { id: 'executive', label: 'Executive', labelFr: 'Executive' },
  { id: 'portfolio', label: 'Portfolio', labelFr: 'Portfolio' },
  { id: 'tech', label: 'Tech', labelFr: 'Tech' },
  { id: 'consulting', label: 'Consulting', labelFr: 'Consulting' },
]);

/**
 * Per-template gallery card metadata.
 * @type {Record<string, { useCases: GalleryUseCase[], hiringSuccess: string, visualStyle: string }>}
 */
export const PREMIUM_TEMPLATE_GALLERY_META = Object.freeze({
  'consulting-elite': {
    useCases: ['consulting', 'executive'],
    hiringSuccess: 'MBB case interview ready',
    visualStyle: 'Cormorant + IBM Plex · 3/9 split · KPI strip',
  },
  'apple-style': {
    useCases: ['tech', 'executive', 'portfolio'],
    hiringSuccess: 'Keynote clarity · document-first',
    visualStyle: 'SF Pro monument · timeline spine · hairline rules',
  },
  'google-style': {
    useCases: ['tech', 'ats'],
    hiringSuccess: '92% engineering screen pass',
    visualStyle: 'Material color bar · 26/74 rail · stack chips',
  },
  'startup-founder': {
    useCases: ['tech', 'executive'],
    hiringSuccess: 'Founder-operator venture shortlist',
    visualStyle: 'Linear purple · traction strip · operator split',
  },
  'creative-director': {
    useCases: ['creative', 'portfolio'],
    hiringSuccess: 'Creative director portfolio pick',
    visualStyle: 'Fraunces hero · coral accent · client grid',
  },
  'senior-engineer': {
    useCases: ['tech', 'ats'],
    hiringSuccess: 'Staff+ engineering credibility',
    visualStyle: 'JetBrains mono rail · dense system cards',
  },
  'executive-board': {
    useCases: ['executive'],
    hiringSuccess: 'C-suite board-ready',
    visualStyle: 'Source Serif · gold rule · board masthead',
  },
  'minimal-ats': {
    useCases: ['ats', 'tech'],
    hiringSuccess: '97% recruiter parse · ultra-dense',
    visualStyle: 'Inter tabular · 68ch · date-role grid',
  },
  academic: {
    useCases: ['consulting', 'executive'],
    hiringSuccess: 'Faculty & research shortlist',
    visualStyle: 'EB Garamond · scholarly 32/68 split',
  },
  'luxury-editorial': {
    useCases: ['creative', 'portfolio', 'consulting'],
    hiringSuccess: 'Editorial luxury shortlist',
    visualStyle: 'Playfair cover · 22/48/30 magazine spread',
  },
  'luxury-executive': {
    useCases: ['executive'],
    hiringSuccess: 'C-suite board-ready · Apple keynote clarity',
    visualStyle: 'Apple monument · hairline gold rule · Source Serif gravitas',
  },
  'mckinsey-consulting': {
    useCases: ['consulting', 'executive'],
    hiringSuccess: 'MBB case interview ready',
    visualStyle: 'McKinsey navy · 4/8 split · impact matrix',
  },
  'creative-director-portfolio': {
    useCases: ['creative', 'portfolio'],
    hiringSuccess: 'Creative director portfolio pick',
    visualStyle: 'Airbnb warmth · coral accent · client grid',
  },
  'startup-founder': {
    useCases: ['tech', 'executive'],
    hiringSuccess: 'Founder-operator venture shortlist',
    visualStyle: 'Linear purple · traction strip · operator split',
  },
  'tech-engineer': {
    useCases: ['tech', 'ats'],
    hiringSuccess: '92% engineering screen pass',
    visualStyle: 'Google color bar · dark skills rail · mono stack',
  },
  'classic-corporate': {
    useCases: ['executive', 'consulting', 'ats'],
    hiringSuccess: 'Corporate credibility · 94%',
    visualStyle: 'Tesla precision · institutional masthead · red accent',
  },
  'apple-minimal': {
    useCases: ['tech', 'executive', 'portfolio'],
    hiringSuccess: 'Document-first clarity',
    visualStyle: 'Notion warm gray · subtle borders · timeline spine',
  },
  'ats-recruiter': {
    useCases: ['ats', 'tech'],
    hiringSuccess: '97% recruiter parse · page-1 hire density',
    visualStyle: 'Stripe indigo · dense single column · date-role grid',
  },
  ats: {
    useCases: ['ats', 'tech'],
    hiringSuccess: '98% ATS readability',
    visualStyle: 'System sans · pure black & white',
  },
  'ats-elite': {
    useCases: ['ats', 'tech'],
    hiringSuccess: '96% parse success · dense hire',
    visualStyle: 'ATS Clean · Google · Stripe · Linear density',
  },
  'ats-executive': {
    useCases: ['executive', 'consulting', 'ats'],
    hiringSuccess: 'Board-ready minimal · page-1 density',
    visualStyle: 'Executive Minimal · tight meta grid',
  },
  'executive-luxury': {
    useCases: ['executive', 'consulting'],
    hiringSuccess: 'C-suite shortlist ready',
    visualStyle: 'Luxury Serif · McKinsey impact metrics',
  },
  'swiss-editorial': {
    useCases: ['consulting', 'executive'],
    hiringSuccess: 'Classic corporate credibility · 94%',
    visualStyle: 'Classic Corporate · Neue Grafik grid',
  },
  'creative-director': {
    useCases: ['creative', 'portfolio'],
    hiringSuccess: 'Creative portfolio shortlist',
    visualStyle: 'Creative Portfolio · Kinfolk whitespace',
  },
  'editorial-magazine': {
    useCases: ['creative', 'portfolio', 'consulting'],
    hiringSuccess: 'Modern editorial · keynote beauty',
    visualStyle: 'Modern Editorial · 54pt display spread',
  },
  'startup-builder': {
    useCases: ['tech', 'executive'],
    hiringSuccess: 'Founder-operator shortlist',
    visualStyle: 'Traction metrics · green venture hero',
  },
  'agency-designer': {
    useCases: ['creative', 'consulting'],
    hiringSuccess: 'Consultant compact · interview rate',
    visualStyle: 'Consultant Compact · studio split rail',
  },
  'visual-timeline': {
    useCases: ['portfolio', 'tech'],
    hiringSuccess: 'Career story · keynote clarity',
    visualStyle: 'Apple keynote timeline · blue accent',
  },
  'tech-structured': {
    useCases: ['tech', 'ats'],
    hiringSuccess: '92% engineering screen pass',
    visualStyle: 'Dark skills rail · mono identity',
  },
  'art-director-portfolio': {
    useCases: ['portfolio', 'creative'],
    hiringSuccess: 'Luxury campaign portfolio pick',
    visualStyle: 'Hero masthead · bronze editorial',
  },
});

/**
 * @param {string} templateId
 * @param {GalleryUseCase} [filter]
 */
export function templateMatchesGalleryFilter(templateId, filter = 'all') {
  if (!filter || filter === 'all') return true;
  const meta = PREMIUM_TEMPLATE_GALLERY_META[templateId];
  if (!meta) return false;
  return meta.useCases.includes(filter);
}

/**
 * @param {string} templateId
 * @param {object} [tpl] Hirely template record
 */
export function galleryCardMeta(templateId, tpl = {}) {
  const custom = PREMIUM_TEMPLATE_GALLERY_META[templateId] || {};
  return {
    useCases: custom.useCases || ['creative'],
    hiringSuccess: custom.hiringSuccess || 'Premium hire-ready layout',
    visualStyle: custom.visualStyle || tpl.tagline || tpl.bestFor || tpl.category || 'Premium layout',
    bestFor: tpl.bestFor || tpl.category || 'Professional roles',
  };
}

export function listGalleryUseCases(lang = 'en') {
  const fr = lang === 'fr';
  return PREMIUM_GALLERY_USE_CASES.map((u) => ({
    id: u.id,
    label: fr ? u.labelFr : u.label,
  }));
}
