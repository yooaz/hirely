/**
 * HIRELY Ten Premium Templates — production gallery (professional redesign).
 * Same finalResumeData · render-only · dedicated CSS per template.
 */
import {
  TEN_PREMIUM_TEMPLATE_IDS,
  TEN_PREMIUM_TEMPLATE_NAMES,
  TEN_PREMIUM_TEMPLATES_VERSION,
} from './ten-premium-templates.mjs';

export const PREMIUM_TEMPLATE_SYSTEM_V1_IDS = [...TEN_PREMIUM_TEMPLATE_IDS];

/** @deprecated use PREMIUM_TEMPLATE_SYSTEM_V1_IDS */
export const PRODUCTION_TEMPLATE_IDS = PREMIUM_TEMPLATE_SYSTEM_V1_IDS;

export const FEATURED_TEMPLATE_IDS = [...TEN_PREMIUM_TEMPLATE_IDS];

export const PRODUCTION_TEMPLATE_DISPLAY_NAMES = {
  ...TEN_PREMIUM_TEMPLATE_NAMES,
  /* legacy aliases */
  ats: 'ATS Clean',
  'creative-portfolio': 'Creative Portfolio',
  'luxury-minimal': 'Luxury Minimal',
  'portfolio-artist': 'Creative Portfolio',
  creative: 'Creative Portfolio',
  'magazine-editorial': 'Editorial Magazine',
  editorial: 'Editorial Magazine',
  'minimal-swiss': 'Luxury Minimal',
  'luxury-fashion': 'Luxury Minimal',
  luxury: 'Luxury Minimal',
  minimal: 'Luxury Minimal',
  swiss: 'Swiss Editorial',
  'art-director': 'Art Director Portfolio',
  artdirector: 'Art Director Portfolio',
  tech: 'Tech Structured',
  'modern-two-column': 'Tech Structured',
  'tech-resume': 'Tech Structured',
  sidebar: 'Agency Designer',
  'behance-showcase': 'Behance Showcase',
  'illustrator-portfolio': 'Illustrator Portfolio',
  founder: 'Startup Builder',
  startup: 'Startup Builder',
};

export const PREMIUM_TEMPLATE_SYSTEM_V1_COUNT = PREMIUM_TEMPLATE_SYSTEM_V1_IDS.length;
export const PRODUCTION_TEMPLATE_COUNT = PREMIUM_TEMPLATE_SYSTEM_V1_COUNT;
export const TEMPLATE_SYSTEM_VERSION = TEN_PREMIUM_TEMPLATES_VERSION;
export const TEMPLATE_SYSTEM_LOCK = 'TEN_PREMIUM_TEMPLATES_V1';
