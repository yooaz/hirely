/**
 * Canonical product import — single path for file/paste/sample/replace.
 *
 * detectFileType → extractText → normalizeText → buildResumeData
 */

import { detectInputFileType } from '../extraction/file-type-detect.js';
import { extractFromFileDetailed } from '../extraction/extract-file.js';
import { getCachedPdfOcrIfReady } from '../extraction/pdf-ocr-cache.js';
import { runHirelyImportFromText } from '../pipeline/hirely-import.js';
import { normalizePipelineTexts, coerceParserInputText } from '../pipeline/pipeline-contract.js';
import {
  buildResumeData,
  assertResumeDataContract,
  resumeDataFromImport,
} from '../resume-data.js';
import { shouldSkipRemoteOcr } from '../runtime/static-mode.js';
import {
  IMPORT_STATUS,
  IMPORT_STATE,
  resolveImportStatus,
  resolveImportState,
  mapImportStateToLegacy,
  importStateAllowsParser,
} from './import-status.js';
import { logOcrPropagation, logOcrPropagate } from '../extraction/ocr-propagation-trace.js';
import {
  hasRenderableImportText,
  hasMeaningfulImportText,
} from './import-render-guard.js';
import {
  assessOcrBeforeParser,
  buildOcrParserBlockedResult,
} from './ocr-parser-gate.js';
import {
  REAL_CV_IMPORT_MIN_CHARS,
  REAL_CV_IMPORT_FAILURE_REASONS,
} from './real-cv-import-constants.js';
import {
  buildEmptyExtractPasteResult,
  ensureImportContentAccounting,
} from './real-cv-import-root.js';
import { OCR_QUALITY_FAIL_MSG } from '../extraction/ocr-quality-score.js';
import { OCR_PARTIAL_REVIEW_MSG } from '../extraction/pdf-extraction-timeout.js';
import { hirelyProductLog } from '../runtime/hirely-debug.js';
import { logResumeDataCounts } from '../runtime/runtime-version.js';
import { resolveHonestImportState } from '../validation/extraction-reliability.js';
import { attachUniversalImportMeta } from './universal-import-pipeline.js';
import {
  isSimpleImportMode,
  simpleCanonicalImportFromFile,
} from './simple-import-mode.js';
import {
  fileNeedsOcrPipeline,
  isOcrAutoImportEnabled,
  ocrConfidenceWarning,
} from './ocr-auto-import.js';
import {
  buildGuaranteedImportResult,
  importFailureUserMessage,
} from './import-fallback-chain.js';

export { detectInputFileType as detectFileType };

/**
 * @param {File} file
 */
function fileKind(file) {
  return detectInputFileType(file).kind;
}

/**
 * @param {object} extracted
 */
function guaranteedOrPaste(extracted, file, fileType, reason) {
  const guaranteed = buildGuaranteedImportResult(
    { ...extracted, file, fileType },
    { fileType, extractionMethod: extracted.extractionMethod }
  );
  if (guaranteed) {
    guaranteed.warnings = [...(guaranteed.warnings || []), reason || 'GUARANTEED_FALLBACK'];
    return attachUniversalImportMeta(guaranteed, { ...extracted, file });
  }
  return attachUniversalImportMeta(
    buildEmptyExtractPasteResult(
      { ...extracted, file },
      fileType,
      extracted.importFailureReason || reason || resolveExtractFailureReason(extracted)
    ),
    { ...extracted, file }
  );
}

/**
 * @param {object} extracted
 */
function resolveExtractFailureReason(extracted) {
  if (extracted.importStatus === IMPORT_STATUS.PDF_OCR_TIMEOUT) {
    return REAL_CV_IMPORT_FAILURE_REASONS.ocr_timeout;
  }
  if (extracted.ocrGate && extracted.ocrGate.pass === false) {
    return REAL_CV_IMPORT_FAILURE_REASONS.ocr_quality;
  }
  return REAL_CV_IMPORT_FAILURE_REASONS.empty_extract;
}

/**
 * @param {File} file
 * @returns {Promise<{ fileType: string, rawText: string, cleanedText: string, extractionMethod: string, warnings: string[], errors: string[], enterprise?: object, pdfExtraction?: object }>}
 */
export async function extractTextFromFile(file) {
  const fileType = fileKind(file);
  const warnings = [];
  const errors = [];

  if (shouldSkipRemoteOcr()) {
    warnings.push('STATIC_MODE_SKIP_REMOTE_OCR');
  }

  try {
    const detailed = await extractFromFileDetailed(file);
    const ent = detailed.enterprise || {};
    const raw = String(ent.rawExtraction || detailed.text || '').trim();
    const cleaned = String(ent.cleanedText || raw).trim();
    logOcrPropagate('CANONICAL_EXTRACT', { CANONICAL_RAW_TEXT_LENGTH: raw.length });
    logOcrPropagation('CANONICAL_EXTRACT', { text: raw, lines: ent.lines || detailed.lines });
    let importState =
      detailed.importState ||
      resolveImportState(raw, {
        errors,
        method: detailed.method,
        extractionMethod: detailed.method || fileType,
      });
    if (
      detailed.enterprise?.pdfExtraction?.recoveredAfterTimeout &&
      raw.length >= REAL_CV_IMPORT_MIN_CHARS
    ) {
      importState = IMPORT_STATE.IMPORT_PARTIAL;
    }
    const importStatus = mapImportStateToLegacy(importState);
    hirelyProductLog('IMPORT_FINAL', importState);
    return {
      fileType,
      rawText: raw,
      cleanedText: cleaned,
      extractionMethod: detailed.method || fileType,
      importState,
      importStatus,
      warnings,
      errors,
      enterprise: detailed.enterprise,
      pdfExtraction: detailed.pdfExtraction,
    };
  } catch (err) {
    const ocrTimedOut =
      err?.code === 'OCR_TIMEOUT' ||
      err?.code === 'OCR_ABSOLUTE_TIMEOUT' ||
      err?.message === 'PDF_EXTRACTION_TIMEOUT';
    if (!ocrTimedOut) {
      console.error('EXTRACT_TEXT_FAILED', err);
    } else {
      hirelyProductLog('OCR_TIMEOUT', { code: err?.code || 'OCR_TIMEOUT' });
    }
    if (ocrTimedOut) {
      const cached = getCachedPdfOcrIfReady(file);
      const cachedText = String(cached?.text || '').trim();
      if (cachedText.length >= REAL_CV_IMPORT_MIN_CHARS) {
        logOcrPropagate('CANONICAL_EXTRACT', {
          CANONICAL_RAW_TEXT_LENGTH: cachedText.length,
          note: 'timeout_cache_recovery',
        });
        hirelyProductLog('OCR_TIMEOUT', { code: err?.code || 'OCR_TIMEOUT', recovered: true });
        hirelyProductLog('IMPORT_FINAL', IMPORT_STATE.IMPORT_PARTIAL);
        return {
          fileType,
          rawText: cachedText,
          cleanedText: cachedText,
          extractionMethod: fileType,
          importState: IMPORT_STATE.IMPORT_PARTIAL,
          importStatus: IMPORT_STATUS.PARTIAL_TEXT_RECOVERED,
          warnings: [...warnings, 'OCR_TIMEOUT'],
          errors,
          enterprise: { rawExtraction: cachedText, lines: cached?.lines || [], method: 'ocr' },
        };
      }
      const msg = OCR_PARTIAL_REVIEW_MSG;
      errors.push(msg);
      hirelyProductLog('OCR_TIMEOUT', { code: err?.code || 'OCR_TIMEOUT' });
      hirelyProductLog('IMPORT_FINAL', IMPORT_STATE.IMPORT_NEEDS_PASTE);
      return {
        fileType,
        rawText: '',
        cleanedText: '',
        extractionMethod: fileType,
        importState: IMPORT_STATE.IMPORT_NEEDS_PASTE,
        importStatus: IMPORT_STATUS.PDF_OCR_TIMEOUT,
        warnings: [...warnings, 'OCR_TIMEOUT'],
        errors,
        importFailureReason: REAL_CV_IMPORT_FAILURE_REASONS.ocr_timeout,
      };
    }
    if (err?.code === 'OCR_QUALITY_FAILED') {
      const msg = String(err?.message || OCR_QUALITY_FAIL_MSG);
      errors.push(msg);
      hirelyProductLog('IMPORT_FINAL', IMPORT_STATE.IMPORT_NEEDS_PASTE);
      return {
        fileType,
        rawText: '',
        cleanedText: '',
        extractionMethod: fileType,
        importState: IMPORT_STATE.IMPORT_NEEDS_PASTE,
        importStatus: IMPORT_STATUS.PDF_TEXT_EMPTY,
        warnings: [...warnings, 'OCR_QUALITY_GATE'],
        errors,
        ocrGate: err.ocrQuality || null,
        importFailureReason: REAL_CV_IMPORT_FAILURE_REASONS.ocr_quality,
      };
    }
    const cached = getCachedPdfOcrIfReady(file);
    const cachedText = String(cached?.text || '').trim();
    const cachedGate = assessOcrBeforeParser(cachedText, {
      method: fileType,
      extractionMethod: fileType,
      lines: cached?.lines,
    });
    if (cachedText.length >= REAL_CV_IMPORT_MIN_CHARS && cachedGate.pass) {
      logOcrPropagate('CANONICAL_EXTRACT', {
        CANONICAL_RAW_TEXT_LENGTH: cachedText.length,
        note: 'cache_recovery',
      });
      return {
        fileType,
        rawText: cachedText,
        cleanedText: cachedText,
        extractionMethod: fileType,
        importState: IMPORT_STATE.IMPORT_PARTIAL,
        importStatus: IMPORT_STATUS.PARTIAL_TEXT_RECOVERED,
        warnings: [...warnings, 'OCR_CACHE_RECOVERY'],
        errors,
      };
    }
    logOcrPropagate('CANONICAL_EXTRACT', {
      CANONICAL_RAW_TEXT_LENGTH: 0,
      note: err?.code || err?.message || 'EXTRACT_FAILED',
    });
    const msg = String(err?.message || 'EXTRACT_FAILED');
    errors.push(msg);
    const importState = resolveImportState('', { errors, method: fileType });
    hirelyProductLog('IMPORT_FINAL', importState);
    return {
      fileType,
      rawText: '',
      cleanedText: '',
      extractionMethod: fileType,
      importState,
      importStatus: mapImportStateToLegacy(importState),
      warnings,
      errors,
    };
  }
}

/**
 * @param {string} rawText
 * @param {string} [cleanedText]
 */
export function normalizeText(rawText, cleanedText = '') {
  const texts = normalizePipelineTexts(rawText, cleanedText || rawText);
  const clean = coerceParserInputText(texts.cleanedText, texts.rawText);
  return { rawText: texts.rawText, cleanedText: clean || texts.rawText };
}

/**
 * Run full import for a file (extract + parse → resumeData).
 * @param {File} file
 * @param {object} [opts]
 */
export async function canonicalImportFromFile(file, opts = {}) {
  const ocrAuto = isOcrAutoImportEnabled() && fileNeedsOcrPipeline(file);
  if (isSimpleImportMode() && !ocrAuto) {
    return simpleCanonicalImportFromFile(file, opts);
  }
  const fileType = fileKind(file);
  const extracted = await extractTextFromFile(file);

  const importState =
    extracted.importState ||
    resolveImportState(extracted.rawText, {
      errors: extracted.errors,
      extractionMethod: extracted.extractionMethod,
    });

  if (!hasRenderableImportText(extracted.rawText, extracted.cleanedText)) {
    if (ocrAuto && String(extracted.rawText || extracted.cleanedText || '').trim().length > 0) {
      extracted.warnings = [...(extracted.warnings || []), 'OCR_PARTIAL_EMPTY_REVIEW'];
    } else {
      return guaranteedOrPaste(
        { ...extracted, file },
        file,
        fileType,
        extracted.importFailureReason || resolveExtractFailureReason(extracted)
      );
    }
  }

  if (!hasMeaningfulImportText(extracted.rawText, extracted.cleanedText)) {
    return guaranteedOrPaste({ ...extracted, file }, file, fileType, 'thin_text');
  }

  if (!importStateAllowsParser(importState)) {
    return guaranteedOrPaste(
      { ...extracted, file },
      file,
      fileType,
      resolveExtractFailureReason(extracted)
    );
  }

  const norm = normalizeText(extracted.rawText, extracted.cleanedText);
  const ocrGate = assessOcrBeforeParser(norm.rawText, {
    method: extracted.extractionMethod,
    extractionMethod: extracted.extractionMethod,
    fileType: extracted.fileType,
    enterprise: extracted.enterprise,
    lines: extracted.enterprise?.lines,
  });
  const ocrConfidence = Number(ocrGate.qualityScore) || 0;
  const lowConfWarn = ocrConfidenceWarning(ocrConfidence);
  const ocrWarnings = [...extracted.warnings];
  if (lowConfWarn && !ocrGate.skipped) {
    ocrWarnings.push('OCR_LOW_CONFIDENCE');
  }
  if (!ocrGate.pass && !ocrGate.skipped) {
    const guaranteed = buildGuaranteedImportResult(
      {
        ...extracted,
        file,
        fileType,
        rawText: norm.rawText,
        cleanedText: norm.cleanedText,
        extractionMethod: extracted.extractionMethod,
        warnings: [...ocrWarnings, 'OCR_PARSER_GATE'],
        errors: extracted.errors,
        ocrConfidence,
        ocrLowConfidenceWarning: lowConfWarn,
      },
      { fileType, extractionMethod: extracted.extractionMethod }
    );
    if (guaranteed) {
      return attachUniversalImportMeta(guaranteed, {
        ...extracted,
        file,
        rawText: norm.rawText,
        cleanedText: norm.cleanedText,
      });
    }
    return attachUniversalImportMeta(
      buildOcrParserBlockedResult(ocrGate, {
        fileType,
        rawText: norm.rawText,
        cleanedText: norm.cleanedText,
        extractionMethod: extracted.extractionMethod,
        warnings: [...ocrWarnings, 'OCR_PARSER_GATE'],
        errors: extracted.errors,
        enterprise: extracted.enterprise,
        pdfExtraction: extracted.pdfExtraction,
        file,
      }),
      { ...extracted, file, rawText: norm.rawText, cleanedText: norm.cleanedText }
    );
  }
  logOcrPropagation('CANONICAL_BEFORE_PARSER', {
    text: norm.rawText,
    note: importState,
  });
  const imported = await runHirelyImportFromText(norm.rawText, {
    ...opts,
    file,
    extractionMethod: extracted.extractionMethod,
    enterpriseExtraction: extracted.enterprise,
    pdfExtraction: extracted.pdfExtraction,
  });

  let resumeData = buildResumeData({
    importResult: imported,
    rawText: norm.rawText,
    cleanedText: String(imported.cleanedText || norm.cleanedText),
    file,
    fileType,
    extractionMethod: extracted.extractionMethod,
    warnings: [...ocrWarnings, ...(imported.warnings || [])],
    errors: [...extracted.errors, ...(imported.errors || [])],
  });

  const accounted = ensureImportContentAccounting({
    rawText: norm.rawText,
    resumeData,
    reviewQueue: imported.reviewQueue || [],
    rejectedGarbage: resumeData.meta?.rejectedGarbage || [],
  });
  resumeData = accounted.resumeData;

  logResumeDataCounts(resumeData, 'canonicalImportFromFile');

  const honest = resolveHonestImportState({
    proposedState: extracted.importState,
    rawText: norm.rawText,
    cleanedText: String(imported.cleanedText || norm.cleanedText),
    resumeData,
  });

  return attachUniversalImportMeta(
    {
      fileType,
      rawText: norm.rawText,
      cleanedText: String(imported.cleanedText || norm.cleanedText),
      extractionMethod: extracted.extractionMethod,
      importState: honest.state,
      importStatus: imported.importStatus || IMPORT_STATUS.IMPORT_SUCCESS,
      structuredResume: imported.structuredResume,
      templateData: imported.templateData,
      resumeData,
      warnings: resumeData.meta.warnings,
      errors: resumeData.meta.errors,
      blocks: imported.blocks || [],
      debugReport: imported.debugReport || null,
      reviewQueue: accounted.reviewQueue,
      rejectedGarbage: accounted.rejectedGarbage,
      ocrConfidence: ocrGate.skipped ? null : ocrConfidence,
      ocrLowConfidenceWarning: lowConfWarn,
      file,
    },
    {
      ...extracted,
      file,
      rawText: norm.rawText,
      cleanedText: String(imported.cleanedText || norm.cleanedText),
    }
  );
}

/**
 * Paste / sample / replace text — same parser path as file.
 * @param {string} text
 * @param {object} [opts]
 */
export async function canonicalImportFromText(text, opts = {}) {
  const norm = normalizeText(text, text);
  const imported = await runHirelyImportFromText(norm.rawText, opts);
  const resumeData = buildResumeData({
    importResult: imported,
    rawText: norm.rawText,
    cleanedText: String(imported.cleanedText || norm.cleanedText),
    file: opts.file || null,
    fileType: opts.fileType || 'paste',
    extractionMethod: opts.extractionMethod || opts.source || 'paste',
    warnings: imported.warnings || [],
    errors: imported.errors || [],
  });

  return {
    fileType: opts.fileType || 'paste',
    rawText: norm.rawText,
    cleanedText: String(imported.cleanedText || norm.cleanedText),
    extractionMethod: opts.extractionMethod || 'paste',
    structuredResume: imported.structuredResume,
    templateData: imported.templateData,
    resumeData,
    warnings: resumeData.meta.warnings,
    errors: resumeData.meta.errors,
    blocks: imported.blocks || [],
    debugReport: imported.debugReport || null,
    reviewQueue: imported.reviewQueue || [],
  };
}
