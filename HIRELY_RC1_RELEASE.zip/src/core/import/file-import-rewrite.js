/**
 * FILE IMPORT REWRITE — PDF/file must not control the app.
 *
 * Flow: file → extract text (native only, no OCR) → createResumeFromText
 *       extraction fails / timeout → paste mode
 *
 * No OCR. No retries. No loops. Max wait FILE_IMPORT_MAX_MS (5s).
 */
import { detectInputFileType } from '../extraction/file-type-detect.js';
import { buildPdfExtractionDebug } from '../extraction/pdf-extraction-debug.js';
import { resumeDataToCvData } from '../resume-data.js';
import { IMPORT_STATE } from './import-state.js';
import { SIMPLE_IMPORT_MIN_CHARS, PDF_IMAGE_PASTE_MSG } from './v1-import-constants.js';
import { buildGuaranteedImportResult } from './import-fallback-chain.js';
import { runRecruiterExtractionPipeline } from '../extraction/recruiter-extraction-pipeline.js';
import { simpleExtractTextFromFile } from './simple-import-mode.js';

export const FILE_IMPORT_REWRITE_VERSION = 'FILE_IMPORT_REWRITE_V1';

/** Hard cap — PDF import must never block the app longer than this. */
export const FILE_IMPORT_MAX_MS = 5000;

/**
 * @param {Promise<T>} promise
 * @param {number} [ms]
 * @returns {Promise<T>}
 */
export function withFileImportTimeout(promise, ms = FILE_IMPORT_MAX_MS) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error('FILE_IMPORT_TIMEOUT')), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

/**
 * Native text extraction only — never OCR. Times out → empty extract (paste mode).
 * @param {File} file
 * @param {number} [timeoutMs]
 */
export async function extractFileTextNoOcr(file, timeoutMs = FILE_IMPORT_MAX_MS) {
  const kind = detectInputFileType(file).kind;
  try {
    return await withFileImportTimeout(simpleExtractTextFromFile(file), timeoutMs);
  } catch (err) {
    const extractionDebug = await buildPdfExtractionDebug(file, {
      rawText: '',
      ocrAttempted: false,
      ocrResultLength: 0,
    });
    extractionDebug.pasteReason = 'FILE_IMPORT_TIMEOUT';
    extractionDebug.userMessage =
      'La lecture a pris trop de temps. Collez le texte pour continuer.';
    return {
      fileType: kind,
      rawText: '',
      cleanedText: '',
      extractionMethod: 'timeout',
      warnings: ['FILE_IMPORT_TIMEOUT', 'NO_OCR', 'NO_RETRY'],
      errors: [String(err?.message || 'FILE_IMPORT_TIMEOUT')],
      extractionDebug,
    };
  }
}

function canUseExtractedText(rawText) {
  return String(rawText || '').trim().length > SIMPLE_IMPORT_MIN_CHARS;
}

function buildPasteResult(file, extracted, raw, clean) {
  const extractionDebug =
    extracted.extractionDebug ||
    (async () =>
      buildPdfExtractionDebug(file, {
        rawText: raw,
        ocrAttempted: false,
        ocrResultLength: 0,
      }))();

  return Promise.resolve(extractionDebug).then((debug) => {
    if (!debug.pasteReason) {
      debug.pasteReason = raw.length ? 'TEXT_TOO_SHORT' : 'NO_TEXT_EXTRACTED';
    }
    if (!debug.userMessage) debug.userMessage = PDF_IMAGE_PASTE_MSG;
    return {
      file: { name: file.name, type: file.type || '', size: file.size || 0 },
      rawText: raw,
      cleanedText: clean,
      importState: IMPORT_STATE.IMPORT_NEEDS_PASTE,
      importStatus: 'PASTE_FALLBACK_REQUIRED',
      blocks: [],
      structuredResume: null,
      templateData: null,
      resumeData: null,
      errors: extracted.errors?.length ? extracted.errors : [debug.pasteReason],
      warnings: [...(extracted.warnings || []), 'FILE_IMPORT_NEEDS_PASTE', 'NO_OCR'],
      extractionMethod: extracted.extractionMethod || detectInputFileType(file).kind,
      extractionDebug: debug,
      pasteReason: debug.pasteReason,
      pasteMessage: debug.userMessage,
      success: false,
      textFirst: true,
      ocrAttempted: false,
    };
  });
}

/**
 * Text-first file import — single pass, no parser, no OCR.
 * @param {File} file
 * @param {object} [opts]
 * @param {number} [opts.timeoutMs]
 */
export async function rewriteImportFromFile(file, opts = {}) {
  const timeoutMs = opts.timeoutMs ?? FILE_IMPORT_MAX_MS;
  const extracted = await extractFileTextNoOcr(file, timeoutMs);
  const raw = String(extracted.rawText || '').trim();
  const clean = String(extracted.cleanedText || raw).trim();

  if (!canUseExtractedText(raw)) {
    const guaranteed = buildGuaranteedImportResult(
      {
        ...extracted,
        file,
        rawText: raw,
        cleanedText: clean,
        fileType: extracted.fileType || detectInputFileType(file).kind,
        extractionMethod: extracted.extractionMethod,
      },
      {
        fileType: extracted.fileType || detectInputFileType(file).kind,
        extractionMethod: extracted.extractionMethod,
        file,
      }
    );
    if (guaranteed) {
      const extractionDebug =
        extracted.extractionDebug ||
        (await buildPdfExtractionDebug(file, {
          rawText: raw,
          ocrAttempted: false,
          ocrResultLength: 0,
        }));
      return {
        ...guaranteed,
        file: { name: file.name, type: file.type || '', size: file.size || 0 },
        extractionDebug,
        textFirst: true,
        ocrAttempted: false,
        engine: 'guaranteed_fallback',
      };
    }
    return buildPasteResult(file, extracted, raw, clean);
  }

  const recruiter = runRecruiterExtractionPipeline(clean || raw, {
    extractionMethod: extracted.extractionMethod || 'file',
  });
  const resumeData = recruiter.resumeData;
  const templateData = recruiter.templateData;

  const extractionDebug =
    extracted.extractionDebug ||
    (await buildPdfExtractionDebug(file, {
      rawText: raw,
      ocrAttempted: false,
      ocrResultLength: 0,
    }));

  return {
    file: { name: file.name, type: file.type || '', size: file.size || 0 },
    rawText: raw,
    cleanedText: clean,
    importState: IMPORT_STATE.IMPORT_READY,
    importStatus: 'IMPORT_SUCCESS',
    blocks: extracted.enterprise?.lines || [],
    structuredResume: null,
    templateData,
    resumeData,
    cvDataV2: recruiter.cvDataV2,
    errors: extracted.errors || [],
    warnings: [...(extracted.warnings || []), 'TEXT_FIRST_IMPORT', 'NO_OCR', 'NO_PARSER'],
    extractionMethod: extracted.extractionMethod,
    extractionDebug,
    success: true,
    textFirst: true,
    ocrAttempted: false,
    engine: 'createResumeFromText',
  };
}
