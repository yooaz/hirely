/**
 * Single active import run — events and UI updates must match the latest run only.
 */

import { resetImportRunState } from './import-state.js';

let activeImportRunId = 0;

/**
 * @returns {number}
 */
export function beginImportRun() {
  activeImportRunId += 1;
  resetImportRunState(activeImportRunId);
  try {
    globalThis.HIRELY_IMPORT_RUN_ID = activeImportRunId;
  } catch {
    /* ignore */
  }
  return activeImportRunId;
}

/**
 * @returns {number}
 */
export function peekImportRunId() {
  try {
    const g = globalThis.HIRELY_IMPORT_RUN_ID;
    if (g != null && Number(g) > 0) return Number(g);
  } catch {
    /* ignore */
  }
  return activeImportRunId;
}

/**
 * @param {number} [runId]
 */
export function isImportRunCurrent(runId) {
  if (runId == null) return true;
  return Number(runId) === peekImportRunId();
}

/**
 * @param {string} name
 * @param {object} [detail]
 */
export function dispatchImportRunEvent(name, detail = {}) {
  const importRunId = detail.importRunId ?? peekImportRunId();
  if (!isImportRunCurrent(importRunId)) return false;
  try {
    globalThis.dispatchEvent?.(
      new CustomEvent(name, { detail: { ...detail, importRunId } })
    );
    return true;
  } catch {
    return false;
  }
}
