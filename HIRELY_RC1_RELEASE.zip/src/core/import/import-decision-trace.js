/**
 * IMPORT_DECISION trace — exactly one canonical reason before IMPORT_NEEDS_PASTE.
 */
import { SIMPLE_IMPORT_MIN_CHARS } from './v1-import-constants.js';

export const PASTE_MODE_REASON = {
  RAW_TEXT_TOO_SHORT: 'RAW_TEXT_TOO_SHORT',
  NO_SECTIONS_FOUND: 'NO_SECTIONS_FOUND',
  PARSER_FAILED: 'PARSER_FAILED',
  PDF_IMAGE_ONLY: 'PDF_IMAGE_ONLY',
  VALIDATION_FAILED: 'VALIDATION_FAILED',
};

const IMAGE_PASTE_SIGNALS = new Set([
  'PDF_IMAGE_OCR_DISABLED',
  'PDF_IMAGE_OCR_NOT_ATTEMPTED',
  'PDF_PROTECTED',
  'PDF_OPEN_FAILED',
  'PDFJS_MISSING',
  'V1_IMAGE_UNSUPPORTED',
  'v1_image',
]);

const PARSER_FAIL_SIGNALS = new Set([
  'parser_fail_friendly',
  'parser_blocked_ocr',
  'linkedin_merge_apply_fail',
  'core_boot_failed',
  'PARSER_FAILED',
  'parser_fail',
]);

const VALIDATION_FAIL_SIGNALS = new Set([
  'honest_gate',
  'stale_weak_data',
  'VALIDATION_FAILED',
]);

const SHORT_TEXT_SIGNALS = new Set([
  'v1_short_text',
  'v1_empty_text',
  'TEXT_TOO_SHORT',
  'OCR_TEXT_TOO_SHORT',
  'PDF_NATIVE_TEXT_TOO_SHORT',
  'empty_after_pipeline_outer',
  'no_file',
]);

/**
 * @param {object|null} resumeData
 * @param {Record<string, number>|null} sectionCounts
 * @returns {string[]}
 */
export function collectDetectedSections(resumeData, sectionCounts) {
  const sections = [];
  if (sectionCounts && typeof sectionCounts === 'object') {
    if ((sectionCounts.experiences || sectionCounts.experience || 0) > 0) sections.push('experience');
    if ((sectionCounts.education || 0) > 0) sections.push('education');
    if ((sectionCounts.skills || 0) > 0) sections.push('skills');
    if ((sectionCounts.tools || 0) > 0) sections.push('tools');
    if ((sectionCounts.languages || 0) > 0) sections.push('languages');
    if ((sectionCounts.projects || 0) > 0) sections.push('projects');
    if ((sectionCounts.clients || 0) > 0) sections.push('clients');
    if ((sectionCounts.summary || 0) > 0) sections.push('summary');
    if (sections.length) return sections;
  }
  const rd = resumeData && typeof resumeData === 'object' ? resumeData : {};
  if ((rd.experiences || []).length) sections.push('experience');
  if ((rd.education || []).length) sections.push('education');
  if ((rd.skills || []).length) sections.push('skills');
  if ((rd.tools || []).length) sections.push('tools');
  if ((rd.languages || []).length) sections.push('languages');
  if ((rd.projects || []).length) sections.push('projects');
  if ((rd.clients || []).length) sections.push('clients');
  if (String(rd.summary || '').trim().length >= 20) sections.push('summary');
  if ((rd.unsorted || []).some((s) => String(s || '').trim().length > 0)) sections.push('unsorted');
  return sections;
}

/**
 * @param {object} ctx
 * @returns {keyof typeof PASTE_MODE_REASON}
 */
export function resolveReasonForPasteMode(ctx) {
  if (ctx.forceReason && PASTE_MODE_REASON[ctx.forceReason]) {
    return PASTE_MODE_REASON[ctx.forceReason];
  }

  const internal = String(
    ctx.internalReason || ctx.pasteReason || ctx.reason || '',
  ).trim();

  const rawLen = Number(ctx.rawTextLength) || 0;
  const cleanLen = Number(ctx.cleanTextLength) || 0;
  const textLen = Math.max(rawLen, cleanLen);
  const sections = Array.isArray(ctx.detectedSections) ? ctx.detectedSections : [];
  const isScanned = ctx.isScannedPdf === true;
  const isProtected = ctx.isProtectedPdf === true;
  const parserFailed = ctx.parserFailed === true;
  const docType = String(ctx.docType || '');

  if (isProtected || isScanned || docType === 'image') {
    return PASTE_MODE_REASON.PDF_IMAGE_ONLY;
  }
  if (IMAGE_PASTE_SIGNALS.has(internal)) {
    return PASTE_MODE_REASON.PDF_IMAGE_ONLY;
  }
  if (ctx.ocrFailure === true && (docType === 'pdf' || docType === 'image')) {
    return PASTE_MODE_REASON.PDF_IMAGE_ONLY;
  }
  if (
    docType === 'pdf' &&
    ctx.pdfJsTotalLength === 0 &&
    (internal === 'fallback' || internal === 'PDF_IMAGE_OCR_DISABLED' || !internal)
  ) {
    return PASTE_MODE_REASON.PDF_IMAGE_ONLY;
  }

  if (textLen <= SIMPLE_IMPORT_MIN_CHARS || SHORT_TEXT_SIGNALS.has(internal)) {
    return PASTE_MODE_REASON.RAW_TEXT_TOO_SHORT;
  }

  if (parserFailed || PARSER_FAIL_SIGNALS.has(internal)) {
    return PASTE_MODE_REASON.PARSER_FAILED;
  }

  if (sections.length === 0) {
    return PASTE_MODE_REASON.NO_SECTIONS_FOUND;
  }

  if (ctx.validationPassed === false || VALIDATION_FAIL_SIGNALS.has(internal)) {
    return PASTE_MODE_REASON.VALIDATION_FAILED;
  }

  return PASTE_MODE_REASON.RAW_TEXT_TOO_SHORT;
}

/**
 * Emit IMPORT_DECISION console group (always, not debug-gated).
 * @param {object} ctx
 * @returns {string}
 */
export function traceImportDecision(ctx) {
  const reason = resolveReasonForPasteMode(ctx);
  console.group('IMPORT_DECISION');
  console.log('rawTextLength', ctx.rawTextLength ?? 0);
  console.log('cleanTextLength', ctx.cleanTextLength ?? 0);
  console.log('pageCount', ctx.pageCount ?? 0);
  console.log('detectedName', ctx.detectedName ?? null);
  console.log('detectedSections', ctx.detectedSections ?? []);
  console.log('isScannedPdf', !!ctx.isScannedPdf);
  console.log('isProtectedPdf', !!ctx.isProtectedPdf);
  console.log('validationPassed', ctx.validationPassed !== false);
  console.log('reasonForPasteMode', reason);
  console.groupEnd();
  return reason;
}
