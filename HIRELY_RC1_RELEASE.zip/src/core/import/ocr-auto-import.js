/**
 * P0 — Automatic OCR for image/scanned PDFs (Tesseract.js). Never force paste.
 */
import { detectInputFileType } from '../extraction/file-type-detect.js';
import { OCR_CONFIDENCE_WARN_THRESHOLD } from '../extraction/ocr-quality-score.js';

export const OCR_AUTO_IMPORT_VERSION = 'OCR_AUTO_P0_V1';
export { OCR_CONFIDENCE_WARN_THRESHOLD };

export const OCR_ANALYZING_LABEL = 'Analyse du CV...';

export const OCR_LOW_CONFIDENCE_MSG =
  'Extraction OCR partielle — vérifiez le contenu dans Relecture.';

/**
 * @param {File|{ name?: string, type?: string }} file
 */
export function fileNeedsOcrPipeline(file) {
  const kind = detectInputFileType(file).kind;
  return kind === 'pdf' || kind === 'image';
}

export function isOcrAutoImportEnabled() {
  if (globalThis.HIRELY_OCR_DISABLED_V1 === true) return false;
  if (globalThis.HIRELY_OCR_AUTO === false) return false;
  return true;
}

/**
 * @param {number} score 0–100
 */
export function ocrConfidenceWarning(score) {
  const n = Number(score);
  if (!Number.isFinite(n) || n >= OCR_CONFIDENCE_WARN_THRESHOLD) return null;
  return OCR_LOW_CONFIDENCE_MSG;
}

/**
 * @param {number} score
 */
export function formatOcrConfidenceLabel(score) {
  const n = Math.max(0, Math.min(100, Math.round(Number(score) || 0)));
  return `Extraction OCR · ${n}% confiance`;
}
