/**
 * Universal import pipeline — honest outcomes + structured logging per file.
 *
 * Rules:
 * - selectedTextLength >= 300 → parse path
 * - selectedTextLength < 300 → IMPORT_NEEDS_PASTE
 * - Never fake success; never silent fail
 */

import { hirelyProductLog } from '../runtime/hirely-debug.js';
import { IMPORT_STATE } from './import-state.js';
import {
  REAL_CV_IMPORT_MIN_CHARS,
  selectedImportTextLength,
} from './real-cv-import-root.js';

export const UNIVERSAL_IMPORT_PIPELINE_VERSION = 'UNIVERSAL_IMPORT_PIPELINE_V1';

/**
 * @param {object} [ctx]
 */
export function inferIsScanned(ctx = {}) {
  const sourceType = String(ctx.fileType || ctx.sourceType || '').toLowerCase();
  const method = String(ctx.method || ctx.extractionMethod || '').toLowerCase();
  const pdfEx = ctx.pdfExtraction || {};
  return (
    sourceType === 'pdf_scanned' ||
    sourceType === 'pdf_image' ||
    sourceType === 'image' ||
    method === 'ocr' ||
    method === 'image-ocr' ||
    pdfEx.route === 'ocr_full' ||
    pdfEx.fileType === 'pdf_scanned' ||
    pdfEx.routing?.routingReason === 'scanned'
  );
}

/**
 * @param {object} [ctx]
 */
export function inferIsProtected(ctx = {}) {
  const blob = [
    ctx.pdfExtraction?.why,
    ctx.pdfExtraction?.decision,
    ...(ctx.errors || []),
    ...(ctx.warnings || []),
    String(ctx.fileName || ''),
  ].join(' ');
  return /encrypt|password|protected|protég|\/encrypt\b/i.test(blob);
}

/**
 * @param {object} [extracted]
 */
export function collectUniversalImportMetrics(extracted = {}) {
  const ent = extracted.enterprise || {};
  const meta = ent.metadata || {};
  const mf = meta.multiFormat || ent.multiFormat || meta;
  const pdfEx = extracted.pdfExtraction || ent.pdfExtraction || {};
  const raw = String(extracted.rawText || '').trim();
  const clean = String(extracted.cleanedText || '').trim();
  const selectedTextLength = selectedImportTextLength(raw, clean);
  const fileType =
    String(mf.sourceType || extracted.fileType || meta.fileType || '').trim() ||
    String(extracted.inputKind || '');

  return {
    nativeTextLength:
      Number(mf.nativeTextLength ?? meta.nativeTextLength ?? pdfEx.nativeTextLength ?? 0) ||
      0,
    ocrTextLength:
      Number(mf.ocrTextLength ?? meta.ocrTextLength ?? pdfEx.ocrTextLength ?? 0) || 0,
    selectedTextLength,
    fileType,
    pageCount:
      Number(pdfEx.pageCount ?? meta.pages ?? ent.pages ?? mf.pageCount ?? 0) || 0,
    isScanned: inferIsScanned({
      fileType,
      sourceType: fileType,
      method: extracted.extractionMethod || ent.method,
      pdfExtraction: pdfEx,
    }),
    isProtected: inferIsProtected({
      pdfExtraction: pdfEx,
      errors: extracted.errors,
      warnings: extracted.warnings,
      fileName: extracted.file?.name,
    }),
    selectedSource: mf.selectedSource || meta.extractionSource || '',
    minRequired: REAL_CV_IMPORT_MIN_CHARS,
  };
}

/**
 * @param {object} metrics
 * @param {string} [importState]
 */
export function resolveUniversalImportDecision(metrics, importState = '') {
  const shouldParse = metrics.selectedTextLength >= REAL_CV_IMPORT_MIN_CHARS;
  let status = importState || IMPORT_STATE.IMPORT_IDLE;

  if (!shouldParse) {
    status = IMPORT_STATE.IMPORT_NEEDS_PASTE;
  } else if (
    !status ||
    status === IMPORT_STATE.IMPORT_IDLE ||
    status === IMPORT_STATE.IMPORT_READING ||
    status === IMPORT_STATE.IMPORT_EXTRACTING ||
    status === IMPORT_STATE.IMPORT_PARSING
  ) {
    status = IMPORT_STATE.IMPORT_READY;
  }

  return { shouldParse, status };
}

/**
 * @param {object} [extracted]
 * @param {object} [outcome]
 */
export function buildUniversalImportLog(extracted = {}, outcome = {}) {
  const metrics = collectUniversalImportMetrics(extracted);
  const status =
    outcome.importState ||
    extracted.importState ||
    metrics.status ||
    IMPORT_STATE.IMPORT_IDLE;
  const decision = resolveUniversalImportDecision(metrics, status);

  return {
    version: UNIVERSAL_IMPORT_PIPELINE_VERSION,
    fileName: extracted.file?.name || outcome.fileName || '',
    ...metrics,
    status: status || decision.status,
    shouldParse: decision.shouldParse,
    hasResumeData: outcome.resumeData != null,
    failureReason:
      outcome.importFailureReason ||
      extracted.importFailureReason ||
      outcome.extractionMeta?.failureReason ||
      '',
  };
}

/**
 * @param {object} log
 */
export function logUniversalImportPipeline(log) {
  hirelyProductLog('UNIVERSAL_IMPORT_PIPELINE', log);
  return log;
}

/**
 * Attach universal import log to any terminal import result.
 * @param {object} result
 * @param {object} [extracted]
 */
export function attachUniversalImportMeta(result, extracted = {}) {
  const log = buildUniversalImportLog(
    {
      ...extracted,
      rawText: extracted.rawText ?? result.rawText,
      cleanedText: extracted.cleanedText ?? result.cleanedText,
      fileType: extracted.fileType ?? result.fileType,
      extractionMethod: extracted.extractionMethod ?? result.extractionMethod,
      enterprise: extracted.enterprise ?? result.enterprise,
      pdfExtraction: extracted.pdfExtraction ?? result.pdfExtraction,
      errors: extracted.errors ?? result.errors,
      warnings: extracted.warnings ?? result.warnings,
      importFailureReason:
        extracted.importFailureReason ?? result.importFailureReason,
      importState: extracted.importState ?? result.importState,
      file: extracted.file ?? result.file,
    },
    result
  );
  logUniversalImportPipeline(log);
  return {
    ...result,
    extractionMeta: {
      ...(result.extractionMeta || {}),
      universalImport: log,
    },
    universalImportLog: log,
  };
}

/**
 * Enforce 300-char gate — thin text never returns IMPORT_READY.
 * @param {string} importState
 * @param {number} selectedTextLength
 */
export function enforceTextLengthGate(importState, selectedTextLength) {
  if (selectedTextLength >= REAL_CV_IMPORT_MIN_CHARS) return importState;
  if (importState === IMPORT_STATE.IMPORT_READY) {
    return IMPORT_STATE.IMPORT_NEEDS_PASTE;
  }
  return importState || IMPORT_STATE.IMPORT_NEEDS_PASTE;
}
