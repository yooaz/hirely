/** Auto-generated — do not edit. Run: npm run generate:runtime-stamps */
export const HIRELY_RUNTIME_STAMPS = {
  "generatedAt": "2026-06-15T10:28:38.975Z",
  "files": {
    "src/core/parsing/experience-parser.js": "2d3f36bf4d5d",
    "src/core/parsing/import-repair.js": "e1e99441f641",
    "src/core/parsing/resume-output-quality.js": "618250f08890",
    "src/core/pipeline/production-pipeline.js": "8674fac50246",
    "src/core/resume-data.js": "3358f0579308"
  }
};
