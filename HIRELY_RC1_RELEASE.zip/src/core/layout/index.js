/**
 * @module core/layout — P0 layout reconstruction (frozen: no templates/ATS/export/UI).
 */

export {
  LAYOUT_TYPES,
  detectLayout,
  detectLayoutStage,
  isMultiColumnLayoutType,
} from './detect-layout.js';

export {
  COLUMN_IDS,
  findColumnSplitX,
  detectColumns,
  orderBlocksByColumns,
} from './detect-columns.js';

export {
  lineBoundingBox,
  extractLineBlocks,
  mergeAdjacentLineBlocks,
  extractGeometricBlocks,
  geometricBlocksToLayoutBlocks,
  layoutBlocksToExtracted,
} from './block-extractor.js';

export {
  COLUMN_IDS as READING_COLUMN_IDS,
  ORDERED_BLOCK_KINDS,
  compareLinesReadingOrder,
  orderLinesForReading,
  groupOrderedLinesIntoBlocks,
  buildReadingOrder,
  applyReadingOrder,
  buildOrderedBlocks,
  orderLinesForLayout,
  buildReadingBlocksStage,
} from './reading-order.js';

export {
  hasPositionedPdfLines,
  detectPdfTextLayer,
  runPdfBlockEngine,
} from './pdf-block-engine.js';

export {
  reconstructDocument,
  reconstructionToParseReady,
  RECONSTRUCTION_STAGES,
  VISUAL_ROLES,
} from './document-reconstruction.js';

export {
  annotateVisualStructure,
  summarizeVisualStructure,
  isDateLine,
  isListLine,
  isHeadingLine,
} from './visual-features.js';

export {
  SIDEBAR_SECTION_KEYS,
  isSidebarColumn,
  enforceSectionIntegrity,
  groupBlocksIntoSectionRanges,
  geometricBlocksToSectionBlocks,
  reconstructColumnBlocks,
  validateSectionIntegrity,
} from './column-reconstruction.js';

export {
  LAYOUT_MEMORY_VERSION,
  LAYOUT_ZONE,
  buildLayoutMemory,
  buildLayoutMemoryFromPlainText,
  layoutEntryAt,
} from './layout-memory.js';

export { recoverTwoColumnSections } from './two-column-recovery.js';
