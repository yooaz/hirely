/**
 * Offline Tesseract OCR — local /vendor/tesseract only (no CDN).
 */

import { preprocessCanvasForOcr } from './ocr-preprocess.js';
import {
  getLocalTesseractOptions,
  OcrUnavailableError,
} from '../../vendor/tesseract-runtime.js';

export { OcrUnavailableError };

const DEFAULT_LANG = 'fra+eng';

export async function ensureTesseract() {
  if (typeof globalThis.document === 'undefined') throw new Error('OCR requires a browser');
  if (globalThis.Tesseract) return globalThis.Tesseract;
  try {
    if (globalThis.HirelyLazy?.ensureTesseract) {
      await globalThis.HirelyLazy.ensureTesseract();
      return globalThis.Tesseract;
    }
    const mod = await import('../../vendor/csp-safe-loader.js');
    await mod.ensureTesseract();
    return globalThis.Tesseract;
  } catch (err) {
    if (err instanceof OcrUnavailableError || err?.code?.startsWith?.('OCR_')) throw err;
    throw new OcrUnavailableError(err?.message || 'OCR unavailable', 'OCR_UNAVAILABLE');
  }
}

function tesseractOptions(opts = {}) {
  const T = globalThis.Tesseract;
  const psm = opts.tessPsm || '3';
  return {
    ...getLocalTesseractOptions(),
    logger: () => {},
    tessedit_ocr_engine_mode: T?.OEM?.LSTM_ONLY ?? '1',
    tessedit_pageseg_mode: psm,
  };
}

export async function recognizeCanvas(canvas, lang = DEFAULT_LANG) {
  const out = await recognizeCanvasWithLines(canvas, lang);
  return out.text;
}

/**
 * @returns {{ text: string, lines: Array<{ text: string, confidence: number, line: number, x: number, y: number }> }}
 */
export async function recognizeCanvasWithLines(canvas, lang = DEFAULT_LANG, opts = {}) {
  const Tesseract = await ensureTesseract();
  let target = canvas;
  if (!opts.preprocessed) {
    const prep = preprocessCanvasForOcr(canvas, { debug: false });
    target = prep.canvas;
  }
  const { data } = await Tesseract.recognize(target, lang, tesseractOptions(opts));
  const text = String(data?.text || '').trim();
  const lines = [];
  const src = data?.lines?.length ? data.lines : null;
  if (src) {
    src.forEach((line, i) => {
      const t = String(line.text || '').trim();
      if (!t) return;
      lines.push({
        text: t,
        confidence: Math.round(line.confidence ?? 0),
        line: i,
        x: Math.round(line.bbox?.x0 ?? 0),
        y: Math.round(line.bbox?.y1 ?? 0),
      });
    });
  } else if (text) {
    text.split('\n').forEach((t, i) => {
      const s = t.trim();
      if (s) lines.push({ text: s, confidence: 70, line: i, x: 0, y: 0 });
    });
  }
  return { text, lines };
}
