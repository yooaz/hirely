/**
 * Native PDF text extraction with per-line layout (pdf.js).
 */

import { pdfItemsFromTextContent, extractTopZoneLines } from './pdf-first-page.js';
import { assessPdfTextLayer } from './pdf-text-quality.js';
import { corruptionScoreText } from '../parsing/corruption-detector.js';
import { NATIVE_DEFAULT_CONFIDENCE } from './extracted-line.js';

const PAGE_MIN_CHARS = 32;

/**
 * Group items into lines with average x/y.
 * @param {Array<{ text: string, x: number, y: number }>} items
 */
export function groupPdfItemsIntoLineGroups(items) {
  const sorted = [...items].sort((a, b) => {
    if (Math.abs(b.y - a.y) > 6) return b.y - a.y;
    return a.x - b.x;
  });

  const groups = [];
  let current = [];
  let currentY = null;

  for (const item of sorted) {
    if (currentY === null || Math.abs(item.y - currentY) <= 6) {
      current.push(item);
      currentY = currentY === null ? item.y : currentY;
    } else {
      if (current.length) groups.push(current);
      current = [item];
      currentY = item.y;
    }
  }
  if (current.length) groups.push(current);

  return groups
    .map((row) => {
      const sortedRow = [...row].sort((a, b) => a.x - b.x);
      const text = sortedRow
        .map((i) => i.text)
        .join(' ')
        .replace(/\s+/g, ' ')
        .trim();
      const x = Math.min(...sortedRow.map((i) => i.x));
      const y = Math.round(sortedRow.reduce((s, i) => s + i.y, 0) / sortedRow.length);
      const x2 = Math.max(...sortedRow.map((i) => i.x + (i.width || 0)));
      const height = Math.max(...sortedRow.map((i) => i.height || 12), 12);
      return { text, x, y, width: Math.max(x2 - x, 8), height };
    })
    .filter((g) => g.text.length > 1);
}

/**
 * @param {import('pdfjs-dist').PDFDocumentProxy} pdf
 * @returns {Promise<{ pages: Array<{ page: number, lines: import('./extracted-line.js').ExtractedLine[], charCount: number, usable: boolean }>, firstPageHeaderLines: string[] }>}
 */
export async function extractNativePdfLines(pdf) {
  const pages = [];
  let firstPageHeaderLines = [];

  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
    const page = await pdf.getPage(pageNumber);
    const content = await page.getTextContent();
    const items = pdfItemsFromTextContent(content.items);
    if (pageNumber === 1) {
      const viewport = page.getViewport({ scale: 1 });
      firstPageHeaderLines = extractTopZoneLines(items, viewport.height);
    }
    const groups = groupPdfItemsIntoLineGroups(items);
    const pageText = groups.map((g) => g.text).join('\n');
    const quality = assessPdfTextLayer(pageText);
    const corrupt = corruptionScoreText(pageText);
    const lines = groups.map((g, pdfIndex) => ({
      text: g.text,
      rawExtraction: g.text,
      confidence: Math.min(100, Math.max(75, Math.round(quality.confidence || NATIVE_DEFAULT_CONFIDENCE))),
      source: 'native',
      page: pageNumber,
      pdfIndex,
      line: pdfIndex,
      x: g.x,
      y: g.y,
      width: g.width,
      height: g.height,
    }));
    pages.push({
      page: pageNumber,
      lines,
      charCount: pageText.length,
      usable:
        pageText.length >= PAGE_MIN_CHARS &&
        quality.confidence >= 52 &&
        corrupt < 46,
      quality,
    });
  }

  return { pages, firstPageHeaderLines };
}
