/**
 * HIRELY Enterprise Extraction Engine
 * PDF/Image → text layer detection → native pdf.js → OCR fallback → line archive
 */

import { normalizeRawExtract } from '../parsing/clean.js';
import { postProcessOcrText } from '../parsing/ocr-postprocess.js';
import { isBrowser } from './ocr.js';
import { extractNativePdfLines } from './pdf-lines-native.js';
import { ocrPdfPageToLines } from './ocr-lines.js';
import { runCachedTimedPdfOcr } from './pdf-ocr-run.js';
import { probePdfWithPdfLib } from './pdf-lib-probe.js';
import {
  linesToPlainText,
  summarizeLines,
  NATIVE_DEFAULT_CONFIDENCE,
} from './extracted-line.js';
import { buildDocumentTextsFromLines } from './extraction-line-enrich.js';
import { recognizeCanvasWithLines } from './ocr-tesseract.js';
import { preprocessCanvasForOcr } from './ocr-preprocess.js';
import { pushOcrPreprocessPreview } from './extraction-session.js';
import { runOcrWithFusion, isOcrFusionEnabled } from './ocr-multipass.js';
import { ensureTesseract } from './ocr-tesseract.js';
import { corruptionScoreText } from '../parsing/corruption-detector.js';
import {
  recordExtractionAuditStage,
  dedupeExtractedLines,
  dedupePlainText,
} from './extraction-audit.js';
import { logOcrPropagation, logOcrPropagate } from './ocr-propagation-trace.js';
import {
  isExtractionLocked,
  shouldRunOcrForTextLength,
  logExtractionLockSkip,
  EXTRACTION_LOCK_OCR_MIN_CHARS,
} from './extraction-lock.js';

import { extractionSourceLabel, fileTypeLabel } from './file-type-detect.js';
import { detectDocumentStage } from './stages/document-detection.js';
import { planPdfExtraction, PDF_ROUTES, assertNativePdfLines } from './pdf-router.js';
import { selectBestTextSource } from './best-text-source-selection.js';
import {
  REAL_CV_IMPORT_MIN_CHARS,
  REAL_CV_IMPORT_FAILURE_REASONS,
} from '../import/real-cv-import-constants.js';
import { preparePdfLinesForParsing } from './pdf-post-extract.js';
import { buildLayoutMemory } from '../layout/layout-memory.js';
import { assessPdfTextLayer } from './pdf-text-quality.js';
import { hirelyDebugLog, hirelyDebugWarn, hirelyProductLog } from '../runtime/hirely-debug.js';
import {
  setLastEnterpriseExtraction,
  setLastNativePdfProbe,
} from './extraction-session.js';
import { selectBestOcrRotation } from './ocr-rotation-select.js';
import {
  evaluateOcrParserGate,
  OCR_QUALITY_FAIL_MSG,
} from './ocr-quality-score.js';
import { OCR_STATUS, resolveOcrQualityStatus } from './ocr-quality-status.js';
import { peekLastOcrRotationDecision } from './extraction-session.js';

/**
 * @typedef {import('./extracted-line.js').ExtractedLine} ExtractedLine
 * @typedef {import('./extracted-line.js').EnterpriseExtractionMethod} EnterpriseExtractionMethod
 */

/**
 * @typedef {object} EnterpriseExtractionResult
 * @property {string} rawExtraction
 * @property {string} cleanedText
 * @property {string} text legacy alias of cleanedText
 * @property {ExtractedLine[]} lines
 * @property {EnterpriseExtractionMethod} method
 * @property {object} metadata
 * @property {object} pdfExtraction legacy pdf meta for pipeline
 */

function linesFromPlainText(text, source = 'native') {
  const conf = source === 'ocr' ? 75 : NATIVE_DEFAULT_CONFIDENCE;
  return String(text || '')
    .split('\n')
    .map((t, i) => t.trim())
    .filter((t) => t.length > 0)
    .map((t, line) => ({
      text: t,
      rawExtraction: t,
      cleanedText: t,
      confidence: conf,
      source,
      page: 1,
      line,
      x: 0,
      y: 0,
    }));
}

/**
 * @param {File} file
 * @returns {Promise<EnterpriseExtractionResult>}
 */
export async function extractImageEnterprise(file) {
  if (!isBrowser()) throw new Error('Image OCR requires a browser.');
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = reject;
      el.src = url;
    });
    const c = document.createElement('canvas');
    c.width = img.naturalWidth;
    c.height = img.naturalHeight;
    c.getContext('2d').drawImage(img, 0, 0);
    const debug =
      typeof globalThis !== 'undefined' &&
      /(?:\?|&)debug=true/.test(String(globalThis.location?.search || ''));
    if (debug) {
      const prep = preprocessCanvasForOcr(c, {
        viewportWidth: img.naturalWidth,
        viewportHeight: img.naturalHeight,
        debug: true,
        page: 1,
        variant: 'standard',
      });
      if (prep.previews) {
        pushOcrPreprocessPreview({
          page: 1,
          before: prep.previews.before,
          after: prep.previews.after,
          meta: prep.meta,
        });
      }
    }

    const rotationPick = await selectBestOcrRotation(c, {
      viewportWidth: img.naturalWidth,
      viewportHeight: img.naturalHeight,
      page: 1,
    });
    const ocrCanvas = rotationPick.canvas;

    let rawOcr = '';
    let normalizedLines = [];
    if (isOcrFusionEnabled()) {
      const fused = await runOcrWithFusion(ocrCanvas, {
        viewportWidth: img.naturalWidth,
        viewportHeight: img.naturalHeight,
        page: 1,
        skipAutoRotate: true,
        rotationDeg: rotationPick.rotationDeg,
      });
      rawOcr = fused.text;
      normalizedLines = fused.lines;
    } else {
      const prep = preprocessCanvasForOcr(ocrCanvas, {
        viewportWidth: img.naturalWidth,
        viewportHeight: img.naturalHeight,
        variant: rotationPick.variant || 'standard',
        skipAutoRotate: true,
        rotationDeg: rotationPick.rotationDeg,
        page: 1,
      });
      const ocr = await recognizeCanvasWithLines(prep.canvas, 'fra+eng', {
        preprocessed: true,
        tessPsm: prep.meta.suggestedPsm,
      });
      rawOcr = ocr.text;
      normalizedLines = (ocr.lines || []).map((ln, i) => ({
        text: ln.text,
        rawExtraction: ln.text,
        confidence: Math.round(ln.confidence ?? 0),
        source: 'ocr',
        page: 1,
        line: ln.line ?? i,
        x: ln.x ?? 0,
        y: ln.y ?? 0,
      }));
    }
    const imageGate = evaluateOcrParserGate(rawOcr, normalizedLines);
    if (!imageGate.pass) {
      throw Object.assign(new Error(OCR_QUALITY_FAIL_MSG), {
        code: 'OCR_QUALITY_FAILED',
        importStatus: 'PDF_TEXT_EMPTY',
        ocrStatus: OCR_STATUS.FAILED_LOW_QUALITY,
        ocrQuality: imageGate,
      });
    }
    return buildResult({
      lines: normalizedLines,
      ocrDocument: true,
      method: 'ocr',
      fileType: 'image',
      textLayerFound: false,
      confidence: Math.round(
        normalizedLines.reduce((s, l) => s + (l.confidence || 0), 0) /
          Math.max(1, normalizedLines.length)
      ),
      pages: 1,
      pdfExtraction: { method: 'image-ocr', decision: 'ocr', fileType: 'image' },
    });
  } finally {
    URL.revokeObjectURL(url);
  }
}

/**
 * Weak selectable native layer — try local OCR and pick/merge best source.
 * @param {import('pdfjs-dist').PDFDocumentProxy} pdf
 * @param {File|null} file
 * @param {import('./extracted-line.js').ExtractedLine[]} nativeLines
 * @param {string} nativeText
 */
async function supplementWeakNativeWithOcr(pdf, file, nativeLines, nativeText) {
  const nativeLen = String(nativeText || '').trim().length;
  if (nativeLen >= REAL_CV_IMPORT_MIN_CHARS || nativeLen < 12) return null;
  try {
    await ensureTesseract();
    const ocrOut = await runCachedTimedPdfOcr(pdf, file, {
      fusion: pdf.numPages === 1 && isOcrFusionEnabled(),
      bestPass: true,
      allowSecondPass: globalThis.HIRELY_FORCE_PDF_OCR_RETRY === true,
      existingTextLength: nativeLen,
      existingText: nativeText,
      existingLines: nativeLines,
    });
    const ocrLines = ocrOut.lines || [];
    const ocrText = String(ocrOut.text || linesToPlainText(ocrLines)).trim();
    if (ocrText.length < 12) return null;

    const picked = selectBestTextSource({
      nativeText,
      nativeLines,
      ocrText,
      ocrLines,
    });
    const pickedText = String(picked.text || '').trim();
    if (!pickedText || pickedText.length <= nativeLen) return null;

    const outLines =
      picked.lines?.length ?
        picked.lines
      : picked.selectedSource === 'ocr' ?
        ocrLines
      : nativeLines;

    return {
      lines: outLines,
      text: pickedText,
      method: picked.selectedSource === 'ocr' ? 'ocr' : picked.selectedSource === 'merged' ? 'mixed' : 'native_pdf',
      weakNativeSupplemented: true,
      textSourceAudit: picked.audit,
      selectedSource: picked.selectedSource,
      ocrCharCount: ocrText.length,
    };
  } catch (err) {
    hirelyProductLog('WEAK_NATIVE_OCR_SUPPLEMENT_FAILED', {
      reason: REAL_CV_IMPORT_FAILURE_REASONS.weak_native,
      message: String(err?.message || err),
    });
    return null;
  }
}

/**
 * @param {import('pdfjs-dist').PDFDocumentProxy} pdf
 * @param {ArrayBuffer} buffer — clone dedicated to pdf-lib (never shared with pdf.js)
 * @param {{ file?: File }} [ctx]
 */
export async function extractPdfEnterprise(pdf, buffer, ctx = {}) {
  const file = ctx.file || null;
  const pdfLibMeta = await probePdfWithPdfLib(buffer);
  const { pages, firstPageHeaderLines } = await extractNativePdfLines(pdf);
  const allNativeText = pages.map((p) => p.lines.map((l) => l.text).join('\n')).join('\n\n');
  const nativeCorruption = corruptionScoreText(allNativeText);
  const nativeTextBroken =
    nativeCorruption >= 46 &&
    (assessPdfTextLayer(allNativeText).garbageLineRatio > 0.35 ||
      assessPdfTextLayer(allNativeText).alphaRatio < 0.5);

  const { classification: profile, quality: fullQuality, plan, pdfClassification } =
    planPdfExtraction(pages, allNativeText, { nativeTextBroken });

  hirelyDebugLog('HIRELY ENTERPRISE PDF', {
    pages: pdf.numPages,
    fileType: profile.fileType,
    route: plan.route,
    reason: plan.reason,
    textLayerFound: profile.textLayerFound,
    hasSelectableText: profile.hasSelectableText,
    nativeChars: profile.nativeCharCount,
    quality: profile.confidence,
    neverOcrNative: plan.ocrAllowed === false,
    pdfLib: pdfLibMeta,
  });

  /** Route: selectable text layer → native PDF; weak native may supplement with local OCR. */
  if (plan.route === PDF_ROUTES.NATIVE) {
    let lines = pages.flatMap((p) => p.lines);
    assertNativePdfLines(lines);
    let nativeText = linesToPlainText(lines).trim();
    let method = 'native_pdf';
    let fileType = 'pdf_text';
    let pdfDecision = plan.reason;
    let supplementMeta = null;

    if (plan.ocrMode === 'supplement' && plan.ocrAllowed) {
      const supplemented = await supplementWeakNativeWithOcr(pdf, file, lines, nativeText);
      if (supplemented) {
        lines = supplemented.lines;
        nativeText = supplemented.text;
        method = supplemented.method;
        fileType = method === 'ocr' ? 'pdf_scanned' : method === 'mixed' ? 'pdf_mixed' : 'pdf_text';
        pdfDecision = 'weak_native_ocr_supplement';
        supplementMeta = supplemented;
      }
    }

    const quality = assessPdfTextLayer(nativeText);
    return buildResult({
      lines,
      rawExtraction: nativeText,
      cleanedText: nativeText,
      method,
      fileType,
      textLayerFound: true,
      confidence: Math.max(profile.confidence, quality.confidence),
      pages: pdf.numPages,
      pdfExtraction: {
        method,
        decision: pdfDecision,
        fileType,
        extractionSource: extractionSourceLabel(method),
        why: supplementMeta ? 'Weak native layer — OCR supplement applied' : fullQuality.reason,
        charCount: nativeText.length,
        wordCount: quality.wordCount,
        textLayerFound: true,
        ocrSkipped: !supplementMeta,
        neverOcrNative: !supplementMeta,
        weakNativeSupplemented: Boolean(supplementMeta),
        textSourceAudit: supplementMeta?.textSourceAudit || null,
        selectedSource: supplementMeta?.selectedSource || 'native',
        ocrCharCount: supplementMeta?.ocrCharCount || 0,
        routing: plan,
        firstPageHeaderLines,
        pdfLib: pdfLibMeta,
        classification: pdfClassification,
      },
    });
  }

  if (!isBrowser()) {
    throw new Error('Ce PDF semble scanné. Collez le texte du CV ou utilisez TXT/DOCX.');
  }

  /** Route: mixed — native pages + OCR only on pages without text. */
  if (plan.route === PDF_ROUTES.HYBRID) {
    const hybridNativeOnly =
      isExtractionLocked() &&
      !shouldRunOcrForTextLength(allNativeText.trim().length, {
        weakNative: allNativeText.trim().length < REAL_CV_IMPORT_MIN_CHARS,
        usable: fullQuality.usable,
        strongTextLayer: fullQuality.strongTextLayer,
      });
    if (hybridNativeOnly) {
      logExtractionLockSkip('hybrid_route', allNativeText.trim().length);
      const lines = pages.flatMap((p) => p.lines || []);
      return buildResult({
        lines,
        method: 'mixed',
        ocrDocument: false,
        fileType: 'pdf_mixed',
        textLayerFound: profile.textLayerFound,
        confidence: profile.confidence,
        pages: pdf.numPages,
        pdfExtraction: {
          method: 'mixed',
          decision: 'hybrid_native_only_locked',
          fileType: 'pdf_mixed',
          extractionSource: extractionSourceLabel('mixed'),
          why: `EXTRACTION_LOCK: native text ≥ ${EXTRACTION_LOCK_OCR_MIN_CHARS} chars — per-page OCR skipped`,
          charCount: fullQuality.charCount,
          wordCount: fullQuality.wordCount,
          textLayerFound: profile.textLayerFound,
          nativePages: pdf.numPages,
          ocrPages: 0,
          ocrSkippedByLock: true,
          extractionLocked: true,
          routing: plan,
          firstPageHeaderLines,
          pdfLib: pdfLibMeta,
          classification: pdfClassification,
        },
      });
    }

    await ensureTesseract();
    const hybridLines = [];
    for (let n = 1; n <= pdf.numPages; n++) {
      const pageData = pages.find((p) => p.page === n) || pages[n - 1];
      const pageText = (pageData?.lines || []).map((l) => l.text || '').join('\n');
      const pageQuality = assessPdfTextLayer(pageText);
      const pageCorrupt = corruptionScoreText(pageText) >= 46;
      const useNativePage =
        pageData?.usable &&
        pageData.lines?.length &&
        pageQuality.confidence >= 52 &&
        !pageCorrupt;

      if (useNativePage) {
        hybridLines.push(...pageData.lines);
      } else {
        const docTextLen = linesToPlainText(hybridLines).trim().length;
        if (
          !shouldRunOcrForTextLength(docTextLen, {
            weakNative: docTextLen < REAL_CV_IMPORT_MIN_CHARS,
            usable: pageQuality.usable,
            strongTextLayer: pageQuality.strongTextLayer,
          })
        ) {
          logExtractionLockSkip('hybrid_page', docTextLen);
          if (pageData?.lines?.length) hybridLines.push(...pageData.lines);
          continue;
        }
        const { lines: ocrPageLines } = await ocrPdfPageToLines(pdf, n, {
          fusion: pdf.numPages === 1 && isOcrFusionEnabled(),
          bestPass: true,
          allowSecondPass: globalThis.HIRELY_FORCE_PDF_OCR_RETRY === true,
          existingTextLength: docTextLen,
        });
        hybridLines.push(...ocrPageLines);
      }
    }
    return buildResult({
      lines: hybridLines,
      method: 'mixed',
      ocrDocument: true,
      fileType: 'pdf_mixed',
      textLayerFound: profile.textLayerFound,
      confidence: profile.confidence,
      pages: pdf.numPages,
      pdfExtraction: {
        method: 'mixed',
        decision: 'hybrid',
        fileType: 'pdf_mixed',
        extractionSource: extractionSourceLabel('mixed'),
        why: `Hybrid: ${profile.nativePageCount ?? 0} native page(s), OCR on scanned pages only`,
        charCount: fullQuality.charCount,
        wordCount: fullQuality.wordCount,
        textLayerFound: profile.textLayerFound,
        nativePages: profile.nativePageCount,
        ocrPages: pdf.numPages - (profile.nativePageCount ?? 0),
        routing: plan,
        firstPageHeaderLines,
        pdfLib: pdfLibMeta,
        classification: pdfClassification,
      },
    });
  }

  const nativeFlatLines = pages.flatMap((p) => p.lines || []);
  const nativePartialText = linesToPlainText(nativeFlatLines).trim();

  if (
    !shouldRunOcrForTextLength(nativePartialText.length, {
      weakNative: nativePartialText.length < REAL_CV_IMPORT_MIN_CHARS,
      usable: fullQuality.usable,
      strongTextLayer: fullQuality.strongTextLayer,
    })
  ) {
    logExtractionLockSkip('enterprise_full_ocr', nativePartialText.length);
    return buildResult({
      lines: nativeFlatLines,
      method: 'native_pdf',
      fileType: 'pdf_text',
      textLayerFound: profile.textLayerFound,
      confidence: Math.max(profile.confidence, 50),
      pages: pdf.numPages,
      pdfExtraction: {
        method: 'native_pdf',
        decision: 'native_locked_skip_ocr',
        fileType: 'pdf_text',
        extractionSource: extractionSourceLabel('native_pdf'),
        why: `EXTRACTION_LOCK: ${nativePartialText.length} native chars — full OCR skipped`,
        charCount: nativePartialText.length,
        wordCount: fullQuality.wordCount,
        textLayerFound: profile.textLayerFound,
        ocrSkippedByLock: true,
        extractionLocked: true,
        firstPageHeaderLines,
        pdfLib: pdfLibMeta,
        classification: pdfClassification,
      },
    });
  }

  /** Stash native probe before OCR — recoverable if outer timeout fires mid-OCR. */
  if (nativePartialText.length >= 12 && nativeFlatLines.length) {
    setLastNativePdfProbe({ lines: nativeFlatLines, text: nativePartialText });
    setLastEnterpriseExtraction({
      rawExtraction: nativePartialText,
      text: nativePartialText,
      cleanedText: nativePartialText,
      lines: nativeFlatLines.map((l) => ({ ...l })),
      method: 'native_pdf',
      metadata: { fileType: 'pdf_text', nativeProbe: true },
      pdfExtraction: {
        method: 'native_pdf',
        decision: 'native_probe_before_ocr',
        nativePartialFallback: true,
      },
    });
  }

  /** Route: scanned PDF → full-document OCR only */
  await ensureTesseract();
  let ocrLines = [];
  let ocrPlain = '';
  let ocrRecovered = false;
  try {
    const ocrOpts = {
      fusion: pdf.numPages === 1 && isOcrFusionEnabled(),
      bestPass: true,
      allowSecondPass: globalThis.HIRELY_FORCE_PDF_OCR_RETRY === true,
      existingTextLength: nativePartialText.length,
      existingText: nativePartialText,
      existingLines: nativeFlatLines,
    };
    const ocrOut = await runCachedTimedPdfOcr(pdf, file, ocrOpts);
    ocrLines = ocrOut.lines || [];
    ocrPlain = String(ocrOut.text || linesToPlainText(ocrLines)).trim();
    ocrRecovered = ocrOut.recoveredAfterTimeout === true;
    logOcrPropagate('ENTERPRISE_AFTER_OCR', {
      ENTERPRISE_RESULT_TEXT_LENGTH: ocrPlain.length,
      OCR_LINES_COUNT: ocrLines.length,
    });
    logOcrPropagation('ENTERPRISE_AFTER_OCR', { text: ocrPlain, lines: ocrLines });
  } catch (err) {
    const ocrTimedOut =
      err?.code === 'OCR_TIMEOUT' ||
      err?.code === 'OCR_ABSOLUTE_TIMEOUT' ||
      err?.skippedAfterTimeout === true;
    if (ocrTimedOut) {
      hirelyProductLog('OCR_TIMEOUT', { phase: 'enterprise_ocr' });
    } else if (err?.code !== 'OCR_QUALITY_FAILED' && err?.code !== 'OCR_EMPTY') {
      hirelyDebugWarn('HIRELY PDF OCR failed', err?.message || err);
    }
    if (err?.code === 'OCR_QUALITY_FAILED' || err?.code === 'OCR_EMPTY') {
      throw err;
    }
    if (ocrTimedOut && nativePartialText.length < REAL_CV_IMPORT_MIN_CHARS) {
      throw err;
    }
    if (nativePartialText.length >= REAL_CV_IMPORT_MIN_CHARS && nativeFlatLines.length) {
      console.warn('HIRELY PDF OCR fallback → partial native', nativePartialText.length);
      return buildResult({
        lines: nativeFlatLines,
        method: 'native_pdf',
        fileType: 'pdf_text',
        textLayerFound: profile.textLayerFound,
        confidence: Math.max(profile.confidence, 50),
        pages: pdf.numPages,
        pdfExtraction: {
          method: 'native_pdf',
          decision: 'native_after_ocr_fail',
          fileType: 'pdf_text',
          extractionSource: extractionSourceLabel('native_pdf'),
          why: 'OCR failed — partial native PDF text retained',
          charCount: nativePartialText.length,
          nativePartialFallback: true,
          ocrFailed: true,
          firstPageHeaderLines,
          pdfLib: pdfLibMeta,
          classification: pdfClassification,
        },
      });
    }
    throw new Error(
      'OCR du PDF impossible (réseau ou fichier protégé). Collez le texte du CV ou utilisez TXT/DOCX.'
    );
  }
  logOcrPropagation('ENTERPRISE_BEFORE_BUILD', {
    text: ocrPlain || linesToPlainText(ocrLines),
    lines: ocrLines,
  });

  const ocrGate = evaluateOcrParserGate(ocrPlain, ocrLines);
  const rotationMeta = peekLastOcrRotationDecision();
  if (!ocrGate.pass && !ocrRecovered) {
    throw Object.assign(new Error(OCR_QUALITY_FAIL_MSG), {
      code: 'OCR_QUALITY_FAILED',
      importStatus: 'PDF_TEXT_EMPTY',
      ocrStatus: OCR_STATUS.FAILED_LOW_QUALITY,
      ocrQuality: ocrGate,
    });
  }
  if (ocrPlain.length < REAL_CV_IMPORT_MIN_CHARS) {
    throw Object.assign(new Error('OCR_INSUFFICIENT_TEXT'), {
      code: 'OCR_INSUFFICIENT_TEXT',
      importStatus: 'PDF_TEXT_EMPTY',
      textLength: ocrPlain.length,
    });
  }

  const chosenRotation = rotationMeta?.chosenRotation ?? 0;
  const ocrStatus = resolveOcrQualityStatus({
    text: ocrPlain,
    lines: ocrLines,
    gatePass: true,
    chosenRotation,
    acceptedByParser: true,
  });

  return buildResult({
    lines: ocrLines,
    rawExtraction: ocrPlain,
    cleanedText: ocrPlain,
    method: 'ocr',
    ocrDocument: true,
    fileType: 'pdf_scanned',
    textLayerFound: profile.textLayerFound,
    confidence: profile.confidence,
    pages: pdf.numPages,
    pdfExtraction: {
      method: 'ocr',
      decision: 'ocr',
      fileType: 'pdf_scanned',
      extractionSource: extractionSourceLabel('ocr'),
      why: plan.reason,
      charCount: fullQuality.charCount,
      wordCount: fullQuality.wordCount,
      textLayerFound: profile.textLayerFound,
      ocrCharCount: ocrPlain.length || linesToPlainText(ocrLines).trim().length,
      ocrQualityScore: ocrGate.qualityScore,
      ocrStatus,
      ocrRotation: chosenRotation,
      ocrRotationTrials: rotationMeta?.trials ?? null,
      recoveredAfterTimeout: ocrRecovered,
      ocrPages: pdf.numPages,
      nativePages: 0,
      neverOcrNative: false,
      routing: plan,
      firstPageHeaderLines,
      pdfLib: pdfLibMeta,
      classification: pdfClassification,
    },
  });
}

function buildResult({
  rawExtraction: rawExtractionIn,
  cleanedText: cleanedTextIn,
  lines,
  method,
  pdfExtraction,
  fileType = null,
  textLayerFound = null,
  confidence = null,
  pages = null,
  ocrDocument = false,
}) {
  const useOcrClean = ocrDocument || method === 'ocr' || method === 'mixed' || method === 'image';
  recordExtractionAuditStage('pre_dedupe_lines', { lines, pageCount: pages });

  const dedupe = dedupeExtractedLines(lines);
  let workingLines = dedupe.lines;
  if (dedupe.removedLines > 0 || dedupe.removedPages > 0) {
    console.warn('HIRELY extraction dedupe', {
      removedLines: dedupe.removedLines,
      removedPages: dedupe.removedPages,
      before: dedupe.before,
      after: dedupe.after,
    });
  }

  const docTexts = buildDocumentTextsFromLines(workingLines, { ocr: useOcrClean });
  let enrichedLines = docTexts.lines;
  let rawExtraction = rawExtractionIn ?? docTexts.rawExtraction;
  let cleanedText = cleanedTextIn ?? docTexts.cleanedText;

  const textDedupe = dedupePlainText(rawExtraction);
  if (textDedupe.beforeChars !== textDedupe.afterChars) {
    rawExtraction = textDedupe.text;
  }
  const cleanDedupe = dedupePlainText(cleanedText);
  if (cleanDedupe.beforeChars !== cleanDedupe.afterChars) {
    cleanedText = cleanDedupe.text;
  }

  recordExtractionAuditStage('cleaned_text', {
    lines: enrichedLines,
    rawText: rawExtraction,
    cleanText: cleanedText,
    pageCount: pages,
  });

  const prepared = preparePdfLinesForParsing(enrichedLines, {
    rawText: rawExtraction,
    cleanedText,
    ocrLayout: pdfExtraction?.ocrLayout || null,
    pdfExtraction,
  });
  enrichedLines = prepared.lines?.length ? prepared.lines : enrichedLines;
  const layoutStage = prepared.layout;
  const readingStage = prepared.reading;
  const layoutMemory = buildLayoutMemory(enrichedLines, {
    layout: layoutStage,
    orderedLines: readingStage?.orderedLines,
    rawText: rawExtraction,
    cleanedText,
    ocrLayout: pdfExtraction?.ocrLayout || null,
  });
  enrichedLines = layoutMemory.lines?.length ? layoutMemory.lines : enrichedLines;
  if (layoutMemory.parserText?.trim()) {
    cleanedText = layoutMemory.parserText;
  }

  const summary = summarizeLines(enrichedLines);
  const resolvedConfidence =
    confidence ??
    (summary.lineCount
      ? Math.round(
          enrichedLines.reduce((s, l) => s + (l.confidence || 0), 0) / summary.lineCount
        )
      : 0);
  const documentStage = detectDocumentStage({
    method,
    fileType: fileType || pdfExtraction?.fileType,
    pdfClassification: pdfExtraction?.classification || null,
  });

  logOcrPropagate('ENTERPRISE_BUILD_RESULT', {
    ENTERPRISE_RESULT_TEXT_LENGTH: String(rawExtraction || '').trim().length,
    OCR_LINES_COUNT: enrichedLines.length,
  });
  logOcrPropagation('ENTERPRISE_BUILD_RESULT', {
    text: rawExtraction,
    lines: enrichedLines,
    note: `method=${method}`,
  });

  const metadata = {
    extractionMethod: method,
    extractionSource: extractionSourceLabel(method),
    fileType: fileType || pdfExtraction?.fileType || method,
    fileTypeLabel: fileTypeLabel(fileType || pdfExtraction?.fileType),
    documentType: documentStage.documentType,
    layoutType: layoutStage.layoutType,
    layoutLabel: prepared.layoutType,
    confidence: resolvedConfidence,
    pages: pages ?? summary.pageCount,
    textLayerFound: textLayerFound ?? pdfExtraction?.textLayerFound ?? null,
    rawExtraction,
    cleanedText,
    lineCount: summary.lineCount,
    nativeLineCount: summary.nativeLineCount,
    ocrLineCount: summary.ocrLineCount,
    lowConfidenceCount: summary.lowConfidenceCount,
    pageCount: summary.pageCount,
    pdfLib: pdfExtraction?.pdfLib || null,
    engine: 'hirely-production-extraction-v1',
    documentStage,
    layoutStage,
    readingStage,
    layoutMemory,
    readingOrderBeforeParse: true,
    usedGeometryReadingOrder: prepared.usedGeometryReadingOrder,
    usedColumnReconstruction: prepared.usedColumnReconstruction,
    neverRawPdfLineOrder: prepared.neverRawPdfLineOrder,
    neverParseRawPdfText: prepared.neverParseRawPdfText === true,
    parseFromDocumentBlocksOnly: prepared.parseFromDocumentBlocksOnly === true,
    parseFromVisualStructureOnly: prepared.pdfBlockEngine?.parseFromVisualStructureOnly === true,
    documentReconstruction: prepared.documentReconstruction === true,
    visualStructure: prepared.visualStructure || prepared.pdfBlockEngine?.visualStructure || null,
    reconstructionError: prepared.reconstructionError || null,
    documentBlocks: prepared.documentBlocks || [],
    pdfBlockEngine: prepared.pdfBlockEngine || null,
    at: new Date().toISOString(),
  };
  return {
    rawExtraction,
    cleanedText,
    text: cleanedText,
    lines: enrichedLines,
    layoutMemory,
    method,
    metadata,
    documentBlocks: prepared.documentBlocks || [],
    pdfExtraction: { ...pdfExtraction, metadata },
  };
}

/**
 * Wrap plain text imports (paste/txt) with line archive.
 * @param {string} text
 * @param {'paste'|'txt'|'docx'} method
 */
export function extractPlainTextEnterprise(text, method = 'paste') {
  const lines = linesFromPlainText(normalizeRawExtract(text), 'native');
  const fileType = method === 'docx' ? 'docx' : method === 'txt' ? 'txt' : 'txt';
  return buildResult({
    lines,
    method: method === 'docx' ? 'docx' : method === 'txt' ? 'txt' : 'paste',
    fileType,
    textLayerFound: true,
    confidence: NATIVE_DEFAULT_CONFIDENCE,
    pages: 1,
    pdfExtraction: null,
  });
}
