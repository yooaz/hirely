/**
 * OCR extraction with per-line confidence (Tesseract / Vision).
 * Multi-pass fusion runs internally — not exposed to UI.
 */

import { runOcrOnCanvasWithLines } from './ocr-pipeline.js';
import { renderPdfPageToCanvas } from './pdf-ocr-render.js';
import { preprocessCanvasForOcr } from './ocr-preprocess.js';
import { pushOcrPreprocessPreview } from './extraction-session.js';
import { runOcrWithFusion, isOcrFusionEnabled } from './ocr-multipass.js';
import { runOcrBestPass, isOcrBestPassEnabled } from './ocr-best-pass.js';
import { selectBestOcrRotation } from './ocr-rotation-select.js';
import { postProcessOcrText } from '../parsing/ocr-postprocess.js';
import { OCR_FALLBACK_CONFIDENCE } from './extracted-line.js';
import { recordExtractionAuditStage } from './extraction-audit.js';
import { logExtractionStep } from './file-buffer.js';
import { logOcrPropagation, logOcrPropagate } from './ocr-propagation-trace.js';
import { shouldRunOcrForTextLength, logExtractionLockSkip } from './extraction-lock.js';
import { REAL_CV_IMPORT_MIN_CHARS } from '../import/real-cv-import-constants.js';

function isDebugPreprocess() {
  if (typeof globalThis === 'undefined') return false;
  if (globalThis.HIRELY_OCR_PREPROCESS_DEBUG) return true;
  try {
    return /(?:\?|&)debug=true/.test(String(globalThis.location?.search || ''));
  } catch {
    return false;
  }
}

function polishOcrLines(lines) {
  return (lines || []).map((ln) => {
    const raw = String(ln.rawExtraction ?? ln.text ?? '').trim();
    const cleaned = postProcessOcrText(raw);
    if (!cleaned) return null;
    return {
      ...ln,
      text: cleaned,
      cleanedText: cleaned,
      rawExtraction: raw,
    };
  }).filter(Boolean);
}

/** Keep Tesseract text when line polish strips everything (charCount > 0 but join empty). */
function finalizeOcrCanvasOutput(result, page = 1) {
  const raw = String(result?.text || '').trim();
  const polished = result?.lines?.length ? polishOcrLines(result.lines) : [];
  let joined = polished.map((l) => l.text).join('\n').trim();
  let lines = polished;

  if (!joined && raw) {
    const recovered = postProcessOcrText(raw) || raw;
    joined = String(recovered).trim();
    lines = polishOcrLines(
      joined.split('\n').map((t, i) => ({
        text: t,
        rawExtraction: t,
        confidence: OCR_FALLBACK_CONFIDENCE,
        source: 'ocr',
        page,
        line: i,
        x: 0,
        y: 0,
      }))
    );
    if (!lines.length && joined) {
      lines = [
        {
          text: joined,
          cleanedText: joined,
          rawExtraction: raw,
          confidence: OCR_FALLBACK_CONFIDENCE,
          source: 'ocr',
          page,
          line: 0,
          x: 0,
          y: 0,
        },
      ];
    }
    if (joined) {
      logExtractionStep('OCR_TEXT_RECOVERED', `${joined.length}c page=${page}`);
    }
  }

  logOcrPropagate('OCR_CANVAS', {
    OCR_RESULT_TEXT_LENGTH: raw.length,
    OCR_LINES_COUNT: lines.length,
    OCR_JOINED_TEXT_LENGTH: joined.length,
    page,
  });

  return { text: joined, lines };
}

async function ocrCanvasSinglePass(canvas, opts = {}) {
  const page = opts.page || 1;
  const debug = opts.debugPreprocess ?? isDebugPreprocess();
  const prep = preprocessCanvasForOcr(canvas, {
    viewportWidth: opts.viewportWidth || canvas.width,
    viewportHeight: opts.viewportHeight || canvas.height,
    targetDpi: opts.targetDpi,
    variant: opts.preferredVariant || opts.variant || 'standard',
    skipAutoRotate: opts.skipAutoRotate === true,
    rotationDeg: opts.rotationDeg || 0,
    debug,
    page,
  });
  if (prep.previews) {
    pushOcrPreprocessPreview({ page, before: prep.previews.before, after: prep.previews.after, meta: prep.meta });
  }
  try {
    const result = await runOcrOnCanvasWithLines(prep.canvas, {
      lang: opts.lang || 'fra+eng',
      preprocessed: true,
      tessPsm: prep.meta.suggestedPsm,
      preprocessMeta: prep.meta,
    });
    if (result.lines?.length || result.text) {
      return finalizeOcrCanvasOutput(
        {
          text: result.text,
          lines: (result.lines || []).map((ln, i) => ({
            text: ln.text,
            rawExtraction: ln.text,
            confidence: Math.round(ln.confidence ?? OCR_FALLBACK_CONFIDENCE),
            source: 'ocr',
            page,
            line: ln.line ?? i,
            x: ln.x ?? 0,
            y: ln.y ?? 0,
          })),
        },
        page
      );
    }
  } catch (e) {
    console.warn('HIRELY OCR lines', e);
  }
  return { text: '', lines: [] };
}

/**
 * @param {HTMLCanvasElement} canvas
 * @param {{ lang?: string, page?: number, fusion?: boolean }} [opts]
 */
export async function ocrCanvasToLines(canvas, opts = {}) {
  if (opts.variant && opts.fusion !== true) {
    const debug = opts.debugPreprocess ?? isDebugPreprocess();
    const prep = preprocessCanvasForOcr(canvas, {
      viewportWidth: opts.viewportWidth || canvas.width,
      viewportHeight: opts.viewportHeight || canvas.height,
      targetDpi: opts.targetDpi,
      variant: opts.variant,
      skipAutoRotate: opts.skipAutoRotate === true,
      rotationDeg: opts.rotationDeg || 0,
      debug,
      page: opts.page || 1,
    });
    if (prep.previews) {
      pushOcrPreprocessPreview({
        page: opts.page || 1,
        before: prep.previews.before,
        after: prep.previews.after,
        meta: prep.meta,
      });
    }
    const result = await runOcrOnCanvasWithLines(prep.canvas, {
      lang: opts.lang || 'fra+eng',
      preprocessed: true,
      tessPsm: prep.meta.suggestedPsm,
      preprocessMeta: prep.meta,
    });
    if (result.lines?.length || result.text) {
      return finalizeOcrCanvasOutput(result, opts.page || 1);
    }
    return { text: '', lines: [] };
  }
  if (isOcrFusionEnabled(opts)) {
    const debug = opts.debugPreprocess ?? isDebugPreprocess();
    if (debug) {
      const prep = preprocessCanvasForOcr(canvas, {
        viewportWidth: opts.viewportWidth || canvas.width,
        viewportHeight: opts.viewportHeight || canvas.height,
        debug: true,
        page: opts.page || 1,
        variant: 'standard',
      });
      if (prep.previews) {
        pushOcrPreprocessPreview({
          page: opts.page || 1,
          before: prep.previews.before,
          after: prep.previews.after,
          meta: prep.meta,
        });
      }
    }
    const fused = await runOcrWithFusion(canvas, opts);
    if (fused.text || fused.lines.length) {
      return finalizeOcrCanvasOutput(fused, opts.page || 1);
    }
  }
  if (isOcrBestPassEnabled(opts)) {
    const best = await runOcrBestPass(canvas, opts);
    if (best.lines?.length || best.text) {
      const out = finalizeOcrCanvasOutput(best, opts.page || 1);
      return { ...out, ocrBestPass: best.winnerPass };
    }
  }
  return ocrCanvasSinglePass(canvas, opts);
}

/**
 * @param {import('pdfjs-dist').PDFDocumentProxy} pdf
 * @param {number} pageNumber 1-based
 */
export async function ocrPdfPageToLines(pdf, pageNumber, opts = {}) {
  const existingLen = Number(opts.existingTextLength ?? 0) || 0;
  if (
    !shouldRunOcrForTextLength(existingLen, {
      weakNative: existingLen < REAL_CV_IMPORT_MIN_CHARS,
      usable: opts.usable,
      strongTextLayer: opts.strongTextLayer,
    })
  ) {
    logExtractionLockSkip(`ocr_pdf_page_${pageNumber}`, existingLen);
    return { text: '', lines: [], extractionLockSkip: true };
  }

  const page = await pdf.getPage(pageNumber);
  const vp1 = page.getViewport({ scale: 1 });
  const canvas = await renderPdfPageToCanvas(page, opts.scale);
  const rotationPick = await selectBestOcrRotation(canvas, {
    lang: opts.lang,
    page: pageNumber,
    viewportWidth: vp1.width,
    viewportHeight: vp1.height,
    targetDpi: opts.targetDpi,
  });
  const base = {
    ...opts,
    page: pageNumber,
    viewportWidth: vp1.width,
    viewportHeight: vp1.height,
    skipAutoRotate: true,
    rotationDeg: rotationPick.rotationDeg,
    preferredVariant: rotationPick.variant,
  };
  let out = await ocrCanvasToLines(rotationPick.canvas, { ...base, bestPass: opts.bestPass !== false });
  if (!out.lines?.length && !opts.variant && opts.allowSecondPass) {
    out = await ocrCanvasToLines(rotationPick.canvas, {
      ...base,
      variant: 'high_contrast',
      bestPass: false,
    });
  }
  recordExtractionAuditStage(`ocr_page_${pageNumber}`, {
    lines: out.lines,
    rawText: out.text,
    pageCount: 1,
    note: `page ${pageNumber} rotation=${rotationPick.rotationDeg}° score=${rotationPick.qualityScore}`,
  });
  return { ...out, ocrRotation: rotationPick };
}

/**
 * @param {import('pdfjs-dist').PDFDocumentProxy} pdf
 */
export async function ocrPdfAllPagesToLines(pdf, opts = {}) {
  const lines = [];
  const pageTexts = [];
  for (let n = 1; n <= pdf.numPages; n++) {
    const { text, lines: pageLines } = await ocrPdfPageToLines(pdf, n, opts);
    if (text) pageTexts.push(text);
    lines.push(...pageLines);
  }
  const merged = pageTexts.join('\n\n');
  const joinedLen = merged.trim().length;
  logOcrPropagate('OCR_ALL_PAGES', {
    OCR_LINES_COUNT: lines.length,
    OCR_JOINED_TEXT_LENGTH: joinedLen,
    OCR_RESULT_TEXT_LENGTH: joinedLen,
    pages: pdf.numPages,
  });
  logOcrPropagation('OCR_ALL_PAGES', { text: merged, lines, note: `pages=${pdf.numPages}` });
  return { lines, text: merged };
}
