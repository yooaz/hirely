/**
 * Parser layout input — text + line order + spatial positions (never text-only when lines exist).
 */

import {
  buildLayoutMemory,
  buildLayoutMemoryFromPlainText,
} from '../layout/layout-memory.js';

/**
 * @typedef {object} ParserLayoutInput
 * @property {string} text — reading-order cleaned text for section engine
 * @property {import('../layout/layout-memory.js').LayoutMemory|null} layoutMemory
 * @property {import('../extraction/extracted-line.js').ExtractedLine[]} extractionLines
 * @property {string} [rawText]
 */

/**
 * @param {string} cleanedText
 * @param {object} [opts]
 * @returns {ParserLayoutInput}
 */
export function resolveParserLayoutInput(cleanedText, opts = {}) {
  const raw = String(opts.rawText || cleanedText || '').trim();
  const clean = String(cleanedText || '').trim();

  const incomingLines = opts.extractionLines || opts.lines || opts.layoutMemory?.lines;
  const prebuilt = opts.layoutMemory;

  if (prebuilt?.entries?.length) {
    const text = String(prebuilt.parserText || '').trim() || clean || raw;
    return {
      text,
      layoutMemory: prebuilt,
      extractionLines: prebuilt.lines || incomingLines || [],
      rawText: raw,
    };
  }

  if (incomingLines?.length) {
    const layoutMemory = buildLayoutMemory(incomingLines, {
      layout: opts.layout || opts.layoutStage,
      orderedLines: opts.orderedLines || opts.readingStage?.orderedLines,
      rawText: raw,
      cleanedText: clean,
      ocrLayout: opts.ocrLayout,
    });
    const text = layoutMemory.parserText?.trim() || clean || raw;
    return {
      text,
      layoutMemory,
      extractionLines: layoutMemory.lines,
      rawText: raw,
    };
  }

  const sourceText = clean || raw;
  if (sourceText.length >= 1) {
    const layoutMemory = buildLayoutMemoryFromPlainText(sourceText, {
      source: opts.extractionMethod || 'paste',
    });
    return {
      text: layoutMemory.parserText || sourceText,
      layoutMemory,
      extractionLines: layoutMemory.lines,
      rawText: raw,
    };
  }

  return {
    text: '',
    layoutMemory: null,
    extractionLines: [],
    rawText: raw,
  };
}
