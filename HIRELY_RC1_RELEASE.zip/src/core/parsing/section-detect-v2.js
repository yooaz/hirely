/**
 * SECTION_ENGINE_V2 — stage 1: section boundaries via semantic inference (headers optional hints).
 */

import { normalizeHeaderText, fuzzySectionKey, scoreSectionHeader } from './section-fuzzy.js';
import { SECTION_IDS, SECTION_HEADER_ALIASES } from './section-types-v2.js';
import { inferSemanticSectionBlocks } from './semantic-section-infer.js';
import { SEMANTIC_PARSE_MODE } from './semantic-line-types.js';
import { buildDocumentBlocksFromOcrLines } from './block-builder-v1.js';
import { runCvBlockEngine, CV_BLOCK_ENGINE } from './universal-extraction/index.js';
import { recoverTwoColumnSections } from '../layout/two-column-recovery.js';

const INLINE_HEADER_RE = /^([A-Za-zÀ-ÿ][\w\s&/'-]{1,40})\s*[:：]\s*(.+)$/;

/**
 * @param {string} line
 * @returns {string|null} SECTION_IDS value
 */
export function detectSectionHeaderId(line) {
  const trimmed = String(line || '').trim();
  if (!trimmed || trimmed.length > 56) return null;

  const inline = trimmed.match(INLINE_HEADER_RE);
  if (inline) {
    const fromInline = detectSectionHeaderId(inline[1]);
    if (fromInline) return fromInline;
  }

  const norm = normalizeHeaderText(trimmed);
  if (!norm) return null;

  for (const { id, patterns } of SECTION_HEADER_ALIASES) {
    if (patterns.some((re) => re.test(norm))) return id;
  }

  const fuzzy = fuzzySectionKey(trimmed);
  if (fuzzy) {
    const map = {
      summary: SECTION_IDS.SUMMARY,
      profile: SECTION_IDS.PROFILE,
      experience: SECTION_IDS.EXPERIENCE,
      education: SECTION_IDS.EDUCATION,
      skills: SECTION_IDS.SKILLS,
      tools: SECTION_IDS.TOOLS,
      languages: SECTION_IDS.LANGUAGES,
      projects: SECTION_IDS.PROJECTS,
      clients: SECTION_IDS.CLIENTS,
      awards: SECTION_IDS.AWARDS,
      publications: SECTION_IDS.PUBLICATIONS,
      contact: SECTION_IDS.CONTACT,
      interests: SECTION_IDS.INTERESTS,
      certifications: SECTION_IDS.CERTIFICATIONS,
      volunteer: SECTION_IDS.VOLUNTEER,
      exhibitions: SECTION_IDS.EXHIBITIONS,
      portfolioLinks: SECTION_IDS.PORTFOLIO,
      achievements: SECTION_IDS.AWARDS,
      location: SECTION_IDS.CONTACT,
    };
    if (map[fuzzy]) return map[fuzzy];
  }

  if (/^profil\b/i.test(norm) && !/^profile summary/i.test(norm)) return SECTION_IDS.PROFILE;
  return null;
}

/**
 * Primary path: sections → semantic blocks (no regex-first field extraction).
 * @param {string} cleanedText
 * @returns {{ lines: string[], blocks: import('./section-types-v2.js').SectionBlockV2[], semanticLines?: object[], parseMode: string, neverRegexFirstParse: boolean }}
 */
export function detectSectionBlocks(cleanedText, opts = {}) {
  const recovery = recoverTwoColumnSections(cleanedText, {
    ...opts,
    extractionLines: opts.extractionLines || opts.layoutMemory?.lines,
    orderedLines: opts.orderedLines || opts.readingStage?.orderedLines,
    readingStage: opts.readingStage,
  });

  const input =
    recovery.layoutMemory?.entries?.length > 0
      ? recovery.layoutMemory.entries
      : opts.layoutMemory?.entries?.length > 0
        ? opts.layoutMemory.entries
        : cleanedText;
  const built = buildDocumentBlocksFromOcrLines(input, {
    ...opts,
    layoutMemory: recovery.layoutMemory || opts.layoutMemory,
    source: opts.extractionMethod || 'ocr',
  });

  const universal = runCvBlockEngine(built.lines.length ? built.lines : input, {
    ...opts,
    layoutMemory: recovery.layoutMemory || opts.layoutMemory,
    documentBlocks: built.documentBlocks,
  });

  const semantic = recovery.applied
    ? {
        lines: recovery.lines,
        blocks: recovery.blocks,
        semanticLines: recovery.semanticLines,
      }
    : inferSemanticSectionBlocks(built.lines.join('\n'), {
        ...opts,
        layoutMemory: recovery.layoutMemory || opts.layoutMemory,
        documentBlocks: built.documentBlocks,
        lineGroupBlocks: built.documentBlocks,
      });

  return {
    lines: semantic.lines,
    blocks: semantic.blocks,
    semanticLines: semantic.semanticLines,
    documentBlocks: universal.documentBlocks?.length ? universal.documentBlocks : built.documentBlocks,
    lineGroupBlocks: built.documentBlocks,
    universalBlocks: universal.blocks,
    universalBlockStats: universal.stats,
    universalBlockEngine: CV_BLOCK_ENGINE,
    parseMode: SEMANTIC_PARSE_MODE,
    neverRegexFirstParse: true,
    blockStats: built.stats,
    twoColumnRecovery: recovery.applied === true,
    twoColumnStats: recovery.stats || null,
    layoutMemory: recovery.layoutMemory || opts.layoutMemory || null,
    readingStage: recovery.readingStage || opts.readingStage || null,
  };
}

/**
 * Legacy header-boundary detection (optional hint source only).
 * @param {string} cleanedText
 */
export function detectHeaderBasedSectionBlocks(cleanedText) {
  const lines = String(cleanedText || '')
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  /** @type {import('./section-types-v2.js').SectionBlockV2[]} */
  const blocks = [];
  let currentId = SECTION_IDS.PREAMBLE;
  let currentLines = [];
  let headerLine = null;
  let startIdx = 0;

  let lastHeaderConfidence = 55;

  const flush = (endIdx) => {
    if (!currentLines.length && !headerLine) return;
    blocks.push({
      id: `sec-${blocks.length}`,
      type: currentId,
      lines: [...currentLines],
      headerLine,
      startLine: startIdx,
      endLine: endIdx,
      detectedConfidence: headerLine ? lastHeaderConfidence : 55,
    });
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const inline = line.match(INLINE_HEADER_RE);
    let headerId = detectSectionHeaderId(line);
    const scored = scoreSectionHeader(line);

    if (inline && headerId) {
      flush(i);
      currentId = headerId;
      headerLine = line;
      lastHeaderConfidence = scored?.confidence ?? 90;
      currentLines = [inline[2].trim()].filter(Boolean);
      startIdx = i;
      continue;
    }

    if (headerId) {
      flush(i);
      currentId = headerId;
      headerLine = line;
      lastHeaderConfidence = scored?.confidence ?? 88;
      currentLines = [];
      startIdx = i;
      continue;
    }

    currentLines.push(line);
  }
  flush(lines.length);

  if (!blocks.length && lines.length) {
    blocks.push({
      id: 'sec-0',
      type: SECTION_IDS.PREAMBLE,
      lines,
      headerLine: null,
      startLine: 0,
      endLine: lines.length,
      detectedConfidence: 50,
    });
  }

  return { lines, blocks };
}
